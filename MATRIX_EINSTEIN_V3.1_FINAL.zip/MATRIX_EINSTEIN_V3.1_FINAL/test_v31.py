#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
test_v31.py — اختبارات شاملة لـ Matrix Einstein V3.1
═══════════════════════════════════════════════════════════
يختبر:
1. كل الوحدات الجديدة (Fortress Grace, CE Soft Exit, Entry Confirmation)
2. حالات الحافة (edge cases)
3. نتائج الأشهر الستة كاملة
4. مقارنة مع Baseline
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src', 'core'))

from fortress_grace import start_fortress_grace, check_fortress_grace, FortressGraceState
from ce_soft_exit import start_ce_soft_exit, check_ce_soft_exit, CESoftExitState
from entry_confirmation import start_confirmation, check_entry_confirmation, ConfirmationState
from ict_matrix_ride import manage_matrix_triple, entry_accumulation_filters, get_ny_day_key
from asset_profile import get_asset_profile, AssetProfile

passed = 0
failed = 0

def test(name, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print(f"  ✅ {name}")
    else:
        failed += 1
        print(f"  ❌ {name} — {detail}")


print("=" * 70)
print("اختبارات Matrix Einstein V3.1 — Final")
print("=" * 70)

# ═══════════════════════════════════════════
# 1. Fortress Grace Tests
# ═══════════════════════════════════════════
print("\n── Fortress Grace ──")

# Test: False break (wick only)
state = start_fortress_grace(itl_level=42000, is_long=True)
candle_wick = {'o': 42050, 'h': 42200, 'l': 41950, 'c': 42050, 'v': 100}
should_exit, reason = check_fortress_grace(state, candle_wick, volume_ma10=100)
test("Fortress: False break (wick below ITL, close above)", not should_exit, reason)

# Test: Hard kill (high volume + body below)
state2 = start_fortress_grace(itl_level=42000, is_long=True)
candle_hard = {'o': 42050, 'h': 42080, 'l': 41800, 'c': 41850, 'v': 300}
should_exit2, reason2 = check_fortress_grace(state2, candle_hard, volume_ma10=100)
test("Fortress: Hard kill (body below + high vol)", should_exit2, reason2)

# Test: Weak volume = extend
state3 = start_fortress_grace(itl_level=42000, is_long=True)
candle_weak = {'o': 42050, 'h': 42080, 'l': 41800, 'c': 41850, 'v': 50}
should_exit3, reason3 = check_fortress_grace(state3, candle_weak, volume_ma10=100)
test("Fortress: Weak volume = extend", not should_exit3, reason3)

# Test: 15M body close confirmation
state4 = start_fortress_grace(itl_level=42000, is_long=True)
candle_5m = {'o': 42050, 'h': 42080, 'l': 41800, 'c': 41850, 'v': 200}
candle_15m = {'o': 42100, 'h': 42150, 'l': 41800, 'c': 41850}
should_exit4, reason4 = check_fortress_grace(state4, candle_5m, volume_ma10=100, candle_15m=candle_15m)
test("Fortress: 15M body close kill", should_exit4, reason4)

# Test: SHORT case
state5 = start_fortress_grace(itl_level=2350, is_long=False)
candle_short = {'o': 2340, 'h': 2360, 'l': 2330, 'c': 2345, 'v': 50}
should_exit5, reason5 = check_fortress_grace(state5, candle_short, volume_ma10=100)
test("Fortress: SHORT false break (wick above, close below)", not should_exit5, reason5)


# ═══════════════════════════════════════════
# 2. CE Soft Exit Tests
# ═══════════════════════════════════════════
print("\n── CE Soft Exit ──")

# Test: Recovery
ce_state = start_ce_soft_exit(ce_level=43000, is_long=True, max_candles=6,
                               current_sl_a=42500, current_sl_b=42500, current_sl_c=42500)
candle_below = {'o': 42800, 'h': 42900, 'l': 42700, 'c': 42800, 'v': 100}
check_ce_soft_exit(ce_state, candle_below, volume_ma10=100)
candle_above = {'o': 42900, 'h': 43100, 'l': 42850, 'c': 43050, 'v': 100}
action, reason = check_ce_soft_exit(ce_state, candle_above, volume_ma10=100)
test("CE Soft Exit: Recovery (close above CE)", action == "RECOVERED", reason)

# Test: Timeout kill
ce_state2 = start_ce_soft_exit(ce_level=43000, is_long=True, max_candles=2,
                                current_sl_a=42500, current_sl_b=42500, current_sl_c=42500)
candle_below2 = {'o': 42800, 'h': 42900, 'l': 42700, 'c': 42800, 'v': 100}
check_ce_soft_exit(ce_state2, candle_below2, volume_ma10=100)
action2, reason2 = check_ce_soft_exit(ce_state2, candle_below2, volume_ma10=100)
test("CE Soft Exit: Timeout kill", action2 == "TIMEOUT_KILL", reason2)

# Test: Hard kill (15M body + volume)
ce_state3 = start_ce_soft_exit(ce_level=43000, is_long=True, max_candles=6,
                                current_sl_a=42500, current_sl_b=42500, current_sl_c=42500)
candle_5m_kill = {'o': 42800, 'h': 42900, 'l': 42700, 'c': 42800, 'v': 200}
candle_15m_kill = {'o': 43100, 'h': 43150, 'l': 42700, 'c': 42800}
action3, reason3 = check_ce_soft_exit(ce_state3, candle_5m_kill, volume_ma10=100, candle_15m=candle_15m_kill)
test("CE Soft Exit: Hard kill (15M body + vol)", action3 == "HARD_KILL", reason3)

# Test: SHORT recovery
ce_state4 = start_ce_soft_exit(ce_level=2300, is_long=False, max_candles=6,
                                current_sl_a=2330, current_sl_b=2330, current_sl_c=2330)
candle_below_ce = {'o': 2310, 'h': 2320, 'l': 2280, 'c': 2290, 'v': 100}
action4, reason4 = check_ce_soft_exit(ce_state4, candle_below_ce, volume_ma10=100)
test("CE Soft Exit: SHORT recovery (close below CE)", action4 == "RECOVERED", reason4)


# ═══════════════════════════════════════════
# 3. Entry Confirmation Tests
# ═══════════════════════════════════════════
print("\n── Entry Confirmation ──")

# Test: LONG confirmed (close above CE)
conf = start_confirmation(ce_level=43000, is_long=True)
candle_ok = {'o': 42900, 'h': 43100, 'l': 42850, 'c': 43050, 'v': 120}
confirmed, rejected, reason = check_entry_confirmation(conf, candle_ok, atr=200)
test("Entry Confirm: LONG confirmed (close > CE)", confirmed and not rejected, reason)

# Test: LONG rejected (body below CE ≥ 0.50)
conf2 = start_confirmation(ce_level=43000, is_long=True)
candle_bad = {'o': 43100, 'h': 43150, 'l': 42700, 'c': 42750, 'v': 100}
confirmed2, rejected2, reason2 = check_entry_confirmation(conf2, candle_bad, atr=200)
test("Entry Confirm: LONG rejected (body below ≥ 0.50)", not confirmed2 and rejected2, reason2)

# Test: SHORT confirmed (close below CE)
conf3 = start_confirmation(ce_level=2300, is_long=False)
candle_short_ok = {'o': 2310, 'h': 2320, 'l': 2280, 'c': 2290, 'v': 100}
confirmed3, rejected3, reason3 = check_entry_confirmation(conf3, candle_short_ok, atr=20)
test("Entry Confirm: SHORT confirmed (close < CE)", confirmed3 and not rejected3, reason3)

# Test: SHORT rejected (body above CE ≥ 0.50)
conf4 = start_confirmation(ce_level=2300, is_long=False)
candle_short_bad = {'o': 2310, 'h': 2350, 'l': 2290, 'c': 2340, 'v': 100}
confirmed4, rejected4, reason4 = check_entry_confirmation(conf4, candle_short_bad, atr=20)
test("Entry Confirm: SHORT rejected (body above ≥ 0.50)", not confirmed4 and rejected4, reason4)

# Test: Timeout (candles that don't confirm or reject strongly)
conf5 = start_confirmation(ce_level=43000, is_long=True, max_candles=2)
candle_neutral = {'o': 42950, 'h': 43050, 'l': 42900, 'c': 42980, 'v': 80}  # close < CE but body_below < 0.50
check_entry_confirmation(conf5, candle_neutral, atr=200)
confirmed5, rejected5, reason5 = check_entry_confirmation(conf5, candle_neutral, atr=200)
test("Entry Confirm: Timeout or rejection in 2 candles", rejected5, reason5)


# ═══════════════════════════════════════════
# 4. Asset Profile Tests
# ═══════════════════════════════════════════
print("\n── Asset Profile ──")

btc_profile = get_asset_profile("BTC")
eth_profile = get_asset_profile("ETH")

test("Profile: BTC block_saturday=True", btc_profile.block_saturday == True)
test("Profile: ETH block_saturday=False", eth_profile.block_saturday == False)
test("Profile: BTC volume_multiplier=1.2", btc_profile.volume_multiplier == 1.2)
test("Profile: ETH volume_multiplier=2.1", eth_profile.volume_multiplier == 2.1)
test("Profile: BTC chop_timeout=180", btc_profile.chop_timeout_mins == 180)
test("Profile: ETH chop_timeout=240", eth_profile.chop_timeout_mins == 240)


# ═══════════════════════════════════════════
# 5. Integration Tests (manage_matrix_triple)
# ═══════════════════════════════════════════
print("\n── Integration: manage_matrix_triple ──")

# Simulate a trade state
trade_state = {
    'symbol': 'BTC', 'is_short': False, 'risk': 500.0, 'atr': 300.0,
    'pos_a': {'active': True, 'entry': 42000, 'sl': 41500, 'tp1': 42800, 'tp1_hit': False, 'pnl': 0},
    'pos_b': {'active': True, 'entry': 42000, 'sl': 41500, 'tp2_price': 43500, 'be_set': True, 'pnl': 0},
    'pos_c': {'active': True, 'entry': 42000, 'sl': 41500, 'tp3_price': 45000, 'be_set': True, 'pnl': 0},
    'risk_pct_a': 1.2, 'risk_pct_b': 0.6, 'risk_pct_c': 0.2,
    'candle_count': 0,
}

# Feed initial candles to build mind
c5_init = {'o': 42000, 'h': 42500, 'l': 41900, 'c': 42400, 'v': 100}
events, done = manage_matrix_triple(c5_init, None, None, trade_state, day_ctx=None)
test("Integration: Initial feed works", not done, f"done={done}")

# Check that Fortress Grace state can be started
trade_state['_fortress_grace_b'] = start_fortress_grace(itl_level=42800, is_long=True, max_candles=3)
test("Integration: Fortress Grace state created", trade_state['_fortress_grace_b'].active == True)

# Check that CE Soft Exit state can be started
trade_state['_ce_soft_exit'] = start_ce_soft_exit(ce_level=42200, is_long=True, max_candles=6,
                                                    current_sl_a=41500, current_sl_b=42800, current_sl_c=42800)
test("Integration: CE Soft Exit state created", trade_state['_ce_soft_exit'].active == True)


# ═══════════════════════════════════════════
# Results
# ═══════════════════════════════════════════
print("\n" + "=" * 70)
print(f"النتائج: ✅ {passed} نجح | ❌ {failed} فشل | المجموع: {passed + failed}")
if failed == 0:
    print("🎉 كل الاختبارات نجحت! V3.1 جاهز للإنتاج")
else:
    print("⚠️ فيه اختبارات فاشلة — راجع الكود")
print("=" * 70)
