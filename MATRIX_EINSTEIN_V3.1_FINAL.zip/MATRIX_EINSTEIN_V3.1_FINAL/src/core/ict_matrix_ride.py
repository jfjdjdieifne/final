# -*- coding: utf-8 -*-
"""
ict_matrix_ride.py — Interlocking Institutional Defenses (Einstein Brain)
══════════════════════════════════════════════════════════════════════════
عقل واحد متقاطع — مو patches منفصلة.

كل شمعة: يجمع شواهد → يربطها → يستنتج قرار واحد لكل رجل (A/B/C).

المصادر (ICT فقط - بحث معمق):
- 2022 Mentorship Ep2-3: Displacement (velocity + body + FVG) — المصدر: ictkillzone.com Displacement: genuine displacement = large body minimal wicks, breaks prior swing, leaves FVG. Size at least 2x avg recent candle. TradingFinder: after liquidity sweep, switch to lower TF for MSS.
- 2022 Ep11-12-16: Accumulation vs Expansion — ICT notes: Keep perspective limited to 5-day horizon, don't predict more than week. While moving in favor, continue to trust that move and hold.
- 2022 Ep12-13 / Core Month 5: FVG Consequent Encroachment (CE) → wick under CE = rebalance OK; BODY CLOSE under CE = narrative dead — المصدر: innercircletrader.net FVG/IOFED
- ITL as heavier structural fortress (Intermediate-Term Low/High) — المصدر: ICT 2022 Notes: Once an ITL is created it should not be taken out. Trailing below previous bullish OB's low. Down-closed candles should support price.
- ICT Fib extensions -0.5/-1.0/-1.5/-2.0 at DOL expansion — المصدر: tradingstrategyguides.com Day 16: Target 1 at -0.27 extension, Target 2 is named IPDA DOL
- 5-day ADR for exhaustion context — المصدر: complete-ict-trading-strategy-2022
- PD Array zone for ACCUMULATION entries only — لكن بعد BOS يجب إعادة رسم Premium/Discount (المصدر: innercircletrader.net Premium and Discount Zone: Does zone change after BOS? Yes. After every break of structure, mark new PD zone. Bullish: new Discount from fresh low to high)
- Premium/Discount fractal — المصدر: ictflow.com: Premium and discount are fractal — price can be discount on weekly but premium on daily. HTF wins. Drill down until entries align with highest TF bias.
- Mitigation Block = continuation tool — المصدر: innercircletrader.net Mitigation Block Explained: old OB held (no body close past extreme) retested = continuation. Breaker = old OB failed (body close past) = reversal. Body-close test is diagnostic.
- IPDA deterministic — المصدر: master-ipda, interbank price delivery algorithm: price delivery is not random, follows structured rules, seeks liquidity and imbalance. 20/40/60 day ranges.
- Daily Bias Trick — المصدر: innercircletrader.net Daily Bias Trick: Drop to confirmation timeframe 15M or 1H — not lower than 15M. Continue same bias until daily structure flips.
- TP1 قبل أي تحريك للستوب — المصدر: ICT 2022 Mentorship: "Better to take part of your position off and hold onto your same stops. Otherwise, if you trail you will get stopped out early"
- CE اختراق مش = إبطال — المصدر: arongroups.co "A common mistake is calling every move through CE an invalidation", thesimpleict.com "CE penetration alone is not enough for invalidation"
- Trail خلف ITL مش ATR ضيق — المصدر: ICT "trailing below previous bullish OB's low", iqoption.com "Crypto needs 3.0× ATR trailing", blofin.com "Swing trades — wait for +2R before trailing"

NO Soft BE at fixed R.
NO blind bar-by-bar except extreme DOL/ADR exhaustion synthesis.
Deterministic: no randomness, median for robustness, fixed seeds.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
import os
import random

# Determinism Filter — قاعدة 3
# ICT IPDA: price delivery is not random, follows algorithmic rules (source: innercircletrader.net IPDA)
# لذلك نثبت كل بذور العشوائية ونستخدم وسيط بدل متوسط حساس للشواذ
os.environ['PYTHONHASHSEED'] = '0'
random.seed(42)
import numpy as np
np.random.seed(42)

from ict_smart_runner import MarketReader
from ict_sessions import ts_to_ny
from asset_profile import AssetProfile, get_asset_profile
from fortress_grace import FortressGraceState, start_fortress_grace, check_fortress_grace
from ce_soft_exit import CESoftExitState, start_ce_soft_exit, check_ce_soft_exit

PHASE_ACCUM = "ACCUMULATION"
PHASE_EXPAN = "EXPANSION"
ICT_FIB_EXT = (-0.50, -1.00, -1.50, -2.00)

# ═══ ثوابت افتراضية — يُعاد تعيينها ديناميكياً من AssetProfile ═══
# القيم هنا هي fallback — الكود الفعلي يقرأ من state["_profile"]
# المصادر مرجعية موجودة في asset_profile.py
CE_VOTES_NEEDED = 2       # افتراضي BTC — ETH نفس القيمة
CHOP_MINUTES = 180        # افتراضي BTC — ETH = 240
CHOP_MFE_THRESHOLD = 0.3  # نفس القيمة للعملتين
CE_BODY_THRESHOLD = 0.65  # نفس القيمة للعملتين
VOLUME_MULTIPLIER = 1.5   # افتراضي BTC — ETH = 2.1


# ═══════════════════════════════════════════════════════════════
# Primitive perception (eyes) — robust deterministic
# ═══════════════════════════════════════════════════════════════

def _body(c): return abs(float(c["c"]) - float(c["o"]))
def _rng(c): return max(1e-12, float(c["h"]) - float(c["l"]))
def _body_pct(c): return _body(c) / _rng(c)


def mean_body(candles: List[dict], n: int = 12, exclude_last: int = 0) -> float:
    """
    تم تغييره من mean إلى median للـ Determinism Filter:
    - mean حساس لشمعة شاذة واحدة كبيرة (news spike) → يرفع avg → يقلل mult → يظن Displacement ضعيف وهو قوي
    - median مقاوم للشواذ — يعطي rhythm الحقيقي للسوق
    - مصدر: ICT Displacement: Size relative to recent candles matters more than absolute size. Body dominance matters.
    - استخدام median يحافظ على الحتمية ويقلل العشوائية
    """
    if not candles:
        return 0.0
    end = len(candles) - exclude_last if exclude_last else len(candles)
    use = candles[max(0, end - n): end]
    if not use:
        return 0.0
    bodies = [_body(x) for x in use]
    return float(np.median(bodies))  # deterministic robust


def fvg_at(candles: List[dict], mid: int, is_long: bool) -> Optional[dict]:
    """3-candle FVG; mid = displacement candle index."""
    if mid < 1 or mid >= len(candles) - 1:
        return None
    a, b, c = candles[mid - 1], candles[mid], candles[mid + 1]
    if is_long and c["l"] > a["h"]:
        top, bot = float(c["l"]), float(a["h"])
        return {"dir": "BULL", "top": top, "bot": bot, "ce": (top + bot) / 2, "gap": top - bot, "mid": mid, "born": mid}
    if (not is_long) and c["h"] < a["l"]:
        top, bot = float(a["l"]), float(c["h"])
        return {"dir": "BEAR", "top": top, "bot": bot, "ce": (top + bot) / 2, "gap": top - bot, "mid": mid, "born": mid}
    return None


def scan_fvgs(candles: List[dict], is_long: bool, last_n: int = 12) -> List[dict]:
    out = []
    n = len(candles)
    if n < 3:
        return out
    start = max(1, n - last_n)
    for mid in range(start, n - 1):
        f = fvg_at(candles, mid, is_long)
        if f and f["gap"] > 0:
            out.append(f)
    return out


def displacement_impression(candles: List[dict], is_long: bool) -> Dict[str, Any]:
    """
    Weighted institutional fingerprint on candle mid=n-2 (has right neighbor).
    Energy + honesty + FVG — all relative to local rhythm.
    مصدر: ICT Displacement: The Complete Guide — 3 characteristics define genuine displacement:
    1. Size significantly larger than surrounding candles (min 2x avg, often 3-5x)
    2. Body dominance minimal wicks
    3. Creates FVG
    """
    n = len(candles)
    if n < 15:
        return {"score": 0.0, "ready": False, "fvg": None, "detail": "thin_history"}
    mid = n - 2
    c = candles[mid]
    bull = c["c"] > c["o"]
    if is_long and not bull:
        return {"score": 0.0, "ready": False, "fvg": None, "detail": "wrong_dir"}
    if (not is_long) and bull:
        return {"score": 0.0, "ready": False, "fvg": None, "detail": "wrong_dir"}

    avg = mean_body(candles, 12, exclude_last=2)
    body, bp = _body(c), _body_pct(c)
    mult = body / avg if avg > 0 else 0.0

    score = 0.0
    bits = []

    # Relative energy (dynamic continuum, not hard steps only)
    if mult >= 2.0:
        e = min(40.0, max(0.0, (mult - 2.0) / 1.0 * 40.0))
        score += e
        bits.append(f"E={e:.0f}(×{mult:.2f})")
    else:
        bits.append(f"E=0(×{mult:.2f})")

    # Body honesty continuum 0.55→0, 0.75→30
    if bp >= 0.55:
        h = min(30.0, max(0.0, (bp - 0.55) / 0.20 * 30.0))
        score += h
        bits.append(f"H={h:.0f}({bp*100:.0f}%)")
    else:
        bits.append(f"H=0({bp*100:.0f}%)")

    fvg = fvg_at(candles, mid, is_long)
    if fvg and body > 0:
        gr = fvg["gap"] / body
        if gr >= 0.10:
            g = min(30.0, max(0.0, (gr - 0.10) / 0.20 * 30.0))
            score += g
            bits.append(f"G={g:.0f}(gap/b={gr:.2f})")
        else:
            bits.append(f"G=0(gap/b={gr:.2f})")
    else:
        bits.append("G=0(noFVG)")

    return {
        "score": score,
        "ready": score >= 80.0,
        "mult": mult,
        "body_pct": bp,
        "fvg": fvg,
        "detail": " ".join(bits),
    }


def itl_from_reader(reader: MarketReader, is_long: bool) -> Optional[float]:
    if is_long:
        itls = [s for s in reader.swing_lows if s.get("type") == "ITL" and not s.get("broken")]
        return itls[-1]["price"] if itls else None
    iths = [s for s in reader.swing_highs if s.get("type") == "ITH" and not s.get("broken")]
    return iths[-1]["price"] if iths else None


def ict_fib_extension(start: float, end: float, level: float) -> float:
    leg = end - start
    return end + leg * (-level) if level < 0 else end - leg * level


def compute_adr_5(ranges: List[float]) -> Optional[float]:
    if len(ranges) < 3:
        return None
    use = ranges[-5:] if len(ranges) >= 5 else ranges
    return float(np.mean(use))


def get_ny_day_key(ts_ms: int) -> str:
    return ts_to_ny(ts_ms).strftime("%Y-%m-%d")


# ═══════════════════════════════════════════════════════════════
# Accumulation entry perception — with Continuation Protocol (Idea 1)
# ═══════════════════════════════════════════════════════════════

def premium_discount_ok(is_long: bool, dealing: Optional[dict]) -> Tuple[bool, str]:
    """
    القانون الأساسي: لا تشتري في Premium ولا تبيع في Discount
    مصدر: ICT Premium and Discount: Where Smart Money Actually Buys and Sells
    لكن: هذا لمرحلة Accumulation فقط — بعد BOS يجب إعادة رسم المنطقة (innercircletrader.net)
    """
    if not dealing or not dealing.get("zone"):
        return True, "NO_DEALING"
    z = dealing["zone"]
    if is_long and z == "PREMIUM":
        return False, "ACCUM:LONG_IN_PREMIUM"
    if (not is_long) and z == "DISCOUNT":
        return False, "ACCUM:SHORT_IN_DISCOUNT"
    return True, f"ACCUM:PD_{z}"


def midnight_soft(is_long: bool, price: float, midnight_open: Optional[float]) -> str:
    if midnight_open is None or midnight_open <= 0:
        return "NO_MIDNIGHT"
    if is_long:
        return "MID_OK" if price <= midnight_open * 1.0015 else "SOFT_ABOVE_MIDNIGHT"
    return "MID_OK" if price >= midnight_open * 0.9985 else "SOFT_BELOW_MIDNIGHT"


def is_continuation_unlock_thinking(is_long: bool, bias: dict, displacement_score: float, 
                                      dealing_daily: Optional[dict], dealing_15m: Optional[dict],
                                      current_price: float, last_bos_held: bool = True) -> Tuple[bool, str]:
    """
    Continuation Protocol — تفكير وليس رقم ثابت
    الفكرة من المستخدم + بحث معمق:

    المصادر:
    - innercircletrader.net: Does Premium/Discount zone change after BOS? Yes. After every BOS, mark new PD zone. Bullish: new Discount from fresh low to high.
    - ictflow.com: Premium/Discount fractal — price can be discount on weekly but premium on daily. HTF wins. Drill down until entries align with HTF bias.
    - innercircletrader.net Mitigation Block: old OB held (no body close past) retested = continuation. Breaker = failed OB = reversal. Body-close diagnostic.
    - xs.com ICT Trading: Liquidity → Displacement → Premium/Discount → Entry. Continuation setups ride mitigation blocks.
    - ICT 2022 Model: Scenario I — London swept and moved away, NY delivers retracement then continuation in London's direction. Use Fib OTE.

    التفكير:
    الكود يستنتج: "إذا كان الفريم اليومي صاعد بقوة جارفة (bias conf≥70) والـ Displacement خارق (score≥70) وآخر BOS بنفس الاتجاه مع اندفاع و OB القديم صمد (mitigation لا breaker) والسعر الحالي لا يزال تحت DOL اليومي (غرفة للصعود)، فإن الـ Premium الحالي على 15M هو في الحقيقة Discount بالنسبة للقمة التاريخية القادمة (Daily DOL)."

    هذا ليس اختراع — هذا تطبيق حرفي لـ:
    1. New dealing range بعد BOS → old premium تحت new EQ
    2. Mitigation Block continuation → OB صمد
    3. Displacement institutional → يثبت نية
    4. Room to DOL → يوجد سيولة فوق
    """
    # لا نفتح إلا إذا Displacement مؤسساتي حقيقي (خارق) و Bias قوي
    if displacement_score < 70:
        return False, f"CONT:DISP_WEAK_{displacement_score:.0f}<70"
    if bias.get('confidence', 0) < 70:
        return False, f"CONT:BIAS_WEAK_{bias.get('confidence')}<70"

    daily = dealing_daily or bias.get('dealing_range') or {}
    fifteen = dealing_15m or {}

    daily_zone = daily.get('zone')
    fifteen_zone = fifteen.get('zone')

    erl_high = daily.get('erl_high') or (daily.get('high',{}).get('price') if isinstance(daily.get('high'), dict) else None)
    erl_low = daily.get('erl_low') or (daily.get('low',{}).get('price') if isinstance(daily.get('low'), dict) else None)

    if is_long:
        if erl_high and current_price >= erl_high * 0.995:
            return False, "CONT:ALREADY_AT_DOL"
        if fifteen_zone == "PREMIUM" and last_bos_held:
            return True, f"CONTINUATION_UNLOCK_LONG: 15M {fifteen_zone} but Daily {daily_zone} with BOS+Disp({displacement_score:.0f})+OB_HELD → old Premium is new Discount for DOL {erl_high}. Mitigation Block continuation per ICT. LONG only."
    else:
        return False, f"CONT:SHORT_IN_DISCOUNT_BLOCKED_PER_FINAL_REC daily={daily_zone} 15M={fifteen_zone} (only LONG continuation allowed in bullish)"

    return False, f"CONT:NO_NEED daily={daily_zone} 15M={fifteen_zone} OB_HELD={last_bos_held}"


def entry_accumulation_filters(
    is_long: bool,
    entry_price: float,
    bias: dict,
    midnight_open: Optional[float],
    hard_midnight: bool = False,
    displacement_score: Optional[float] = None,
    dealing_15m: Optional[dict] = None,
    last_ob_held: bool = True,
    current_price: Optional[float] = None,
) -> Tuple[bool, str]:
    """
    PD hard (array law). Midnight soft by default.
    لكن مع Continuation Protocol: إذا كان الموقف continuation قوي، نلغي قفل Premium.
    """
    ok, r1 = premium_discount_ok(is_long, bias.get("dealing_range"))
    if not ok:
        if displacement_score is not None:
            unlock, unlock_reason = is_continuation_unlock_thinking(
                is_long, bias, displacement_score,
                bias.get("dealing_range"), dealing_15m,
                current_price or entry_price,
                last_ob_held
            )
            if unlock:
                r2 = midnight_soft(is_long, entry_price, midnight_open)
                if hard_midnight and r2.startswith("SOFT_"):
                    return False, r2
                return True, f"{r1}|CONT_UNLOCKED:{unlock_reason}|{r2}"
        return False, r1
    r2 = midnight_soft(is_long, entry_price, midnight_open)
    if hard_midnight and r2.startswith("SOFT_"):
        return False, r2
    return True, f"{r1}|{r2}"


# ═══════════════════════════════════════════════════════════════
# THE BRAIN — perceives → links → decides (one mind) — with Scale Shift
# ═══════════════════════════════════════════════════════════════

@dataclass
class WorldView:
    phase: str = PHASE_ACCUM
    is_long: bool = True
    entry: float = 0.0
    risk: float = 1.0
    atr: float = 1.0
    price_c: float = 0.0
    price_h: float = 0.0
    price_l: float = 0.0
    price_o: float = 0.0
    mfe_r: float = 0.0
    wave_best: float = 0.0
    impression: Dict[str, Any] = field(default_factory=dict)
    fvgs_15m: List[dict] = field(default_factory=list)
    active_fvg: Optional[dict] = None
    ce: Optional[float] = None
    ce_buffer: float = 0.0
    ce_shield: Optional[float] = None
    itl_15: Optional[float] = None
    itl_1h: Optional[float] = None
    itl_4h: Optional[float] = None
    hard_fortress: Optional[float] = None
    soft_fortress: Optional[float] = None
    body_close_kills_ce: bool = False
    wick_only_into_ce: bool = False
    adr: Optional[float] = None
    adr_fuel: float = 1.0
    near_dol_b: bool = False
    near_dol_c: bool = False
    dol_b: Optional[float] = None
    dol_c: Optional[float] = None
    dol_verdict: str = "NONE"
    extend_b: Optional[float] = None
    extend_c: Optional[float] = None
    extreme_exhaustion: bool = False
    scale_shift_active: bool = False
    narrative: str = ""


class InstitutionalMind:
    def __init__(self):
        self.candles_5m: List[dict] = []
        self.candles_15m: List[dict] = []
        self._bucket_5 = 0
        self.reader_15 = MarketReader()
        self.reader_1h = MarketReader()
        self.reader_4h = MarketReader()
        self.phase = PHASE_ACCUM
        self.expansion_tier = 0
        self.active_fvg: Optional[dict] = None
        self.ce_shield: Optional[float] = None
        self.wave_best: Optional[float] = None
        self.bar_trail_armed = False
        self.narrative_log: List[str] = []
        # ═══ تتبع الحجم للتصويت الثلاثي ═══
        # مصدر: iqoption.com — "Crypto volume confirms institutional participation"
        self.volumes: List[float] = []  # آخر أحجام 5M

    def feed(self, c5, c1h, c4h):
        # تخزين الحجم لو متوفر
        vol = c5.get("v", 0)
        if vol > 0:
            self.volumes.append(float(vol))
            if len(self.volumes) > 60:
                self.volumes = self.volumes[-60:]

        self.candles_5m.append(dict(c5))
        if len(self.candles_5m) > 120:
            self.candles_5m = self.candles_5m[-120:]
        self._bucket_5 += 1
        if self._bucket_5 >= 3:
            b = self.candles_5m[-3:]
            bar15 = {
                "o": b[0]["o"], "h": max(x["h"] for x in b),
                "l": min(x["l"] for x in b), "c": b[-1]["c"],
            }
            self.candles_15m.append(bar15)
            if len(self.candles_15m) > 60:
                self.candles_15m = self.candles_15m[-60:]
            self.reader_15.add_candle(bar15)
            self._bucket_5 = 0
        if c1h:
            self.reader_1h.add_candle(c1h)
        if c4h:
            self.reader_4h.add_candle(c4h)

    def perceive(self, state: dict, c5: dict, day_ctx: Optional[dict]) -> WorldView:
        is_long = not state["is_short"]
        entry = state["pos_a"]["entry"]
        risk = state["risk"]
        atr = state.get("atr", 1.0)
        o, h, l, c = c5["o"], c5["h"], c5["l"], c5["c"]

        if self.wave_best is None:
            self.wave_best = entry
        if is_long:
            self.wave_best = max(self.wave_best, h)
            mfe = (self.wave_best - entry) / risk if risk > 0 else 0
        else:
            self.wave_best = min(self.wave_best, l)
            mfe = (entry - self.wave_best) / risk if risk > 0 else 0

        imp = displacement_impression(self.candles_5m, is_long)
        if self.phase != PHASE_EXPAN and imp.get("ready"):
            self.phase = PHASE_EXPAN
            if imp.get("fvg"):
                self.active_fvg = imp["fvg"]
            self.narrative_log.append(f"EXPANSION_LOCK score={imp['score']:.0f}")

        fvgs = scan_fvgs(self.candles_15m, is_long, last_n=15)
        avg15 = mean_body(self.candles_15m, 8) if self.candles_15m else 0
        qualified = []
        for f in fvgs:
            if avg15 <= 0 or f["gap"] >= avg15 * 0.15:
                if is_long and f["ce"] < self.wave_best:
                    qualified.append(f)
                elif (not is_long) and f["ce"] > self.wave_best:
                    qualified.append(f)
        if qualified:
            cand = qualified[-1]
            if self.active_fvg is None:
                self.active_fvg = cand
            else:
                prev_ce = self.active_fvg["ce"]
                if is_long and cand["ce"] > prev_ce:
                    self.active_fvg = cand
                elif (not is_long) and cand["ce"] < prev_ce:
                    self.active_fvg = cand

        ce = self.active_fvg["ce"] if self.active_fvg else None
        if self.active_fvg and ce is not None:
            gap = self.active_fvg["gap"]
            buf = max(atr * 0.08, gap * 0.05)
            ce_shield = (ce - buf) if is_long else (ce + buf)
            self.ce_shield = ce_shield
        else:
            buf = atr * 0.1
            ce_shield = self.ce_shield

        body_kill = False
        wick_only = False
        if ce is not None and self.active_fvg is not None and len(self.candles_15m) >= 1:
            last15 = self.candles_15m[-1]
            gap = max(self.active_fvg["gap"], atr * 0.05)
            pen = gap * 0.10
            opp_energy = _body_pct(last15) >= 0.55 and (
                (is_long and last15["c"] < last15["o"]) or
                ((not is_long) and last15["c"] > last15["o"])
            )
            if is_long:
                if last15["c"] < ce - pen and (mfe < 1.0 or opp_energy):
                    body_kill = True
                elif last15["l"] < ce <= last15["c"]:
                    wick_only = True
                elif last15["c"] < ce and not opp_energy and mfe >= 1.0:
                    wick_only = True
            else:
                if last15["c"] > ce + pen and (mfe < 1.0 or opp_energy):
                    body_kill = True
                elif last15["h"] > ce >= last15["c"]:
                    wick_only = True
                elif last15["c"] > ce and not opp_energy and mfe >= 1.0:
                    wick_only = True

        itl15 = itl_from_reader(self.reader_15, is_long)
        itl1h = itl_from_reader(self.reader_1h, is_long)
        itl4h = itl_from_reader(self.reader_4h, is_long)

        candidates = []
        for lvl, w in ((itl15, 1.0), (itl1h, 1.2), (itl4h, 1.5)):
            if lvl is None:
                continue
            if is_long and lvl < c:
                candidates.append((lvl, w))
            if (not is_long) and lvl > c:
                candidates.append((lvl, w))
        hard = None
        if candidates:
            if is_long:
                hard = max(candidates, key=lambda x: (x[0], x[1]))[0]
            else:
                hard = min(candidates, key=lambda x: (x[0], -x[1]))[0]

        adr = None
        fuel = 1.0
        if day_ctx:
            adr = compute_adr_5(day_ctx.get("hist_ranges") or [])
            if adr and adr > 0 and day_ctx.get("day_high") is not None:
                d_o = day_ctx.get("day_open")
                if d_o is not None:
                    used = max(0.0, day_ctx["day_high"] - d_o) if is_long else max(0.0, d_o - day_ctx["day_low"])
                else:
                    used = day_ctx["day_high"] - day_ctx["day_low"]
                fuel = max(0.0, 1.0 - used / adr)

        pb = state.get("pos_b", {})
        pc = state.get("pos_c", {})
        dol_b = pb.get("tp2_price")
        dol_c = pc.get("tp3_price")
        near_b = bool(dol_b and ((h >= dol_b) if is_long else (l <= dol_b)))
        near_c = bool(dol_c and ((h >= dol_c) if is_long else (l <= dol_c)))

        dol_verdict = "NONE"
        ext_b = ext_c = None
        if self.phase == PHASE_EXPAN and near_b and dol_b is not None:
            avg_b = mean_body(self.candles_5m[:-1], 12)
            body, bp = _body(c5), _body_pct(c5)
            mult = body / avg_b if avg_b > 0 else 0
            upper = (h - max(o, c)) / _rng(c5)
            lower = (min(o, c) - l) / _rng(c5)
            if is_long:
                rej = upper >= 0.45 and bp < 0.45 and c < dol_b
                run = c > dol_b and bp >= 0.72 and mult >= 2.0 and upper < 0.28
            else:
                rej = lower >= 0.45 and bp < 0.45 and c > dol_b
                run = c < dol_b and bp >= 0.72 and mult >= 2.0 and lower < 0.28
            if rej and not run:
                dol_verdict = "TURTLE"
            elif run:
                dol_verdict = "EXTEND"
                ss, se = (day_ctx or {}).get("setup_start"), (day_ctx or {}).get("setup_end")
                if ss is not None and se is not None:
                    for i, lvl in enumerate(ICT_FIB_EXT):
                        if i < self.expansion_tier:
                            continue
                        proj = ict_fib_extension(ss, se, lvl)
                        if is_long and proj > dol_b:
                            ext_b, self.expansion_tier = proj, i + 1
                            break
                        if (not is_long) and proj < dol_b:
                            ext_b, self.expansion_tier = proj, i + 1
                            break
                if ext_b is None:
                    step = max(atr * 1.5, abs(c - dol_b))
                    ext_b = dol_b + step if is_long else dol_b - step
                if ss is not None and se is not None:
                    deep = ict_fib_extension(ss, se, -1.50)
                    if is_long and (dol_c is None or deep > dol_c):
                        ext_c = deep
                    if (not is_long) and (dol_c is None or deep < dol_c):
                        ext_c = deep
                self.bar_trail_armed = True
            else:
                dol_verdict = "WATCH"

        extreme = self.bar_trail_armed or (fuel <= 0.10 and self.phase == PHASE_EXPAN)

        # ═══ Scale Shift Protocol — Harvest Gate ═══
        # المصادر:
        # - ICT 2022 Notes: Keep perspective limited to 5-day horizon. While moving in favor, continue to trust that move and hold.
        # - Daily Bias Trick: Confirmation timeframe 15M or 1H, not lower than 15M.
        # - Mitigation Block: Once ITL created should not be taken out.
        # القاعدة: يُمنع الانتقال لـ 1H/4H طالما تحت 1.5R أو لم يتم Hard Lock (TP1+BE)
        # التفكير: طالما في بداية الصفقة والسعر يتأرجح تحت 1.5R، لازم نمسك المجهر 15M
        # لأن CE_RISK_CUT هو درس الوحيد للنجاة. بمجرد TP1+BE، نسمح Scale Shift لـ 1H
        candle_count = state.get("candle_count", 0)
        hard_locks = hard is not None and ((is_long and hard > entry) or (not is_long and hard < entry))
        scale_shift_active = False
        scale_reason = ""
        if self.phase == PHASE_EXPAN:
            if hard_locks and mfe >= 1.5:
                scale_shift_active = True
                scale_reason = f"HARVEST_GATE MFE={mfe:.2f}R hard={hard:.0f}→1H/4H (TP1+BE locked, safe to scale)"

        # Build narrative
        parts = [f"phase={self.phase}", f"MFE={mfe:.2f}R", f"impr={imp.get('score',0):.0f}"]
        if ce is not None:
            parts.append(f"CE={ce:.2f}")
            if body_kill:
                parts.append("CE_BODY_DEAD")
            elif wick_only:
                parts.append("CE_WICK_REBALANCE")
            else:
                parts.append("CE_HOLDS")
        if hard is not None:
            parts.append(f"ITL_HARD={hard:.2f}")
        parts.append(f"fuel={fuel:.2f}")
        if dol_verdict != "NONE":
            parts.append(f"DOL={dol_verdict}")
        if scale_shift_active:
            parts.append(f"SCALE_SHIFT:{scale_reason}")

        return WorldView(
            phase=self.phase, is_long=is_long, entry=entry, risk=risk, atr=atr,
            price_c=c, price_h=h, price_l=l, price_o=o, mfe_r=mfe, wave_best=self.wave_best,
            impression=imp, fvgs_15m=qualified, active_fvg=self.active_fvg,
            ce=ce, ce_buffer=buf if ce else 0, ce_shield=ce_shield,
            itl_15=itl15, itl_1h=itl1h, itl_4h=itl4h, hard_fortress=hard,
            soft_fortress=ce_shield, body_close_kills_ce=body_kill, wick_only_into_ce=wick_only,
            adr=adr, adr_fuel=fuel, near_dol_b=near_b, near_dol_c=near_c,
            dol_b=dol_b, dol_c=dol_c, dol_verdict=dol_verdict,
            extend_b=ext_b, extend_c=ext_c, extreme_exhaustion=extreme,
            scale_shift_active=scale_shift_active,
            narrative=" | ".join(parts),
        )

    def decide_and_act(self, state: dict, view: WorldView) -> List[str]:
        events = [f"🧠 {view.narrative}"]
        is_long = view.is_long
        atr = view.atr
        risk = view.risk
        entry = view.entry
        pa, pb, pc = state["pos_a"], state["pos_b"], state["pos_c"]

        # Scale Shift: إذا مفعل، لا تقتل الصفقة على 15M CE death — انظر لـ 1H فقط
        if view.scale_shift_active and view.body_close_kills_ce:
            events.append(f"🔄 SCALE_SHIFT_HOLD: ignoring 15M CE death MFE={view.mfe_r:.2f}R → watching 1H ITL {view.itl_1h} / 4H {view.itl_4h}")
            view.body_close_kills_ce = False
            view.wick_only_into_ce = True

        if view.phase == PHASE_EXPAN and view.body_close_kills_ce and view.ce is not None:
            hard = view.hard_fortress
            hard_locks_profit = False
            if hard is not None and risk > 0:
                if is_long and hard > entry:
                    hard_locks_profit = True
                if (not is_long) and hard < entry:
                    hard_locks_profit = True
            risk_cut = view.mfe_r < 1.0

            # ═══ التصويت الثلاثي للـ CE Risk Cut ═══
            # CE اختراق وحده مش = إبطال — لازم تأكيد مؤسساتي
            # المصدر: arongroups.co — "Practical invalidation is better defined as acceptance beyond the gap"
            # + thesimpleict.com — "CE penetration alone is not enough for invalidation"
            # + xs.com ICT Trading: "Institutional selling requires volume + structure break"
            # + iqoption.com: "Crypto volume confirms institutional participation"
            # التصويت الثلاثي: لازم 2 من 3 شروط لإبطال الصفقة:
            #   1. مستشعر السعر: الإغلاق تجاوز CE بجسم قوي (body_pct ≥ 0.65)
            #   2. مستشعر الحجم: الحجم أعلى من 1.2× MA(حجم, 10) = بيع مؤسساتي
            #   3. مستشعر الهيكل: الإغلاق كسر آخر 1H ITL = الهيكل انقلب
            #      مصدر: ICT — "Once an ITL is created it should not be taken out"
            if risk_cut:
                candle_body_pct = abs(view.price_c - view.price_o) / max(1e-12, view.price_h - view.price_l)

                # التصويت 1: جسم مغلق قوي عبر CE
                vote_body = candle_body_pct >= state.get("_ce_body_threshold", CE_BODY_THRESHOLD)

                # التصويت 2: حجم تداول مؤسساتي
                vote_volume = False
                vol_ratio = 0.0
                volumes = state.get("_mind_volumes", [])
                if len(volumes) >= 10:
                    vol_ma10 = float(np.mean(volumes[-10:]))
                    current_vol = volumes[-1] if volumes else 0
                    vote_volume = current_vol > state.get("_volume_multiplier", VOLUME_MULTIPLIER) * vol_ma10
                    vol_ratio = current_vol / max(1, vol_ma10)

                # التصويت 3: كسر هيكلي (إغلاق تحت آخر 1H ITL للشراء)
                vote_structure = False
                if is_long and view.itl_1h is not None:
                    vote_structure = view.price_c < view.itl_1h
                elif (not is_long) and view.itl_1h is not None:
                    vote_structure = view.price_c > view.itl_1h

                total_votes = int(vote_body) + int(vote_volume) + int(vote_structure)

                if total_votes >= state.get("_ce_votes_needed", CE_VOTES_NEEDED):
                    # ═══ UPGRADE 3: CE Soft Exit — بدل القتل الفوري ═══
                    # مصدر: ICT Core Month 5 — "CE penetration alone is not enough for invalidation"
                    # بدل ما نقتل الصفقة فوراً → نبدأ نافذة خروج ناعم
                    # ننقل SL لـ CE (خسارة شبه معدومة) وننتظر 6 شموع
                    ce_level = view.ce
                    if ce_level is not None and not state.get("_ce_soft_exit"):
                        state["_ce_soft_exit"] = start_ce_soft_exit(
                            ce_level=ce_level,
                            is_long=is_long,
                            current_sl_a=pa.get("sl", 0),
                            current_sl_b=pb.get("sl", 0),
                            current_sl_c=pc.get("sl", 0),
                            max_candles=6,
                        )
                        # نقل SL لسعر الدخول (breakeven حقيقي)
                        # ⚠️ ما نستخدم CE مباشرة لأنه ممكن يكون تحت/فوق الدخول حسب الاتجاه
                        # سعر الدخول = breakeven مضمون لكلا الاتجاهين
                        # لما SL يضرب → SURVIVAL بيعطي +0.5R (لو MFE ≥ 0.5R) أو 0R (breakeven)
                        # هاد أفضل من CE_RISK_CUT اللي بيقتل بخسارة
                        for p in (pa, pb, pc):
                            if p.get("active"):
                                p["sl"] = p["entry"]
                        events.append(
                            f"🔄 CE_SOFT_EXIT_STARTED: votes={total_votes}/3 body={candle_body_pct:.2f} "
                            f"vol×{vol_ratio:.1f} struct={'Y' if vote_structure else 'N'} → "
                            f"SLs→entry (breakeven), 6-candle CE recovery window"
                        )
                        risk_cut = False  # لا نقتل — الخروج الناعم يتولى الأمر
                    else:
                        # لا CE متوفر أو soft exit فعّال → fallback: اقتل عادي
                        events.append(f"☠️ CE_TRIPLE_VOTE body={candle_body_pct:.2f} vol×{vol_ratio:.1f} struct={'Y' if vote_structure else 'N'} votes={total_votes}/3 → KILL (fallback)")
                else:
                    # لا يكفي أصوات — هذا مجرد wick rebalance
                    risk_cut = False
                    events.append(f"🔄 CE_VOTE_HOLD body={candle_body_pct:.2f} vol={'HIGH' if vote_volume else 'LOW'} struct={'BROKEN' if vote_structure else 'INTACT'} votes={total_votes}/{state.get('_ce_votes_needed', CE_VOTES_NEEDED)} (need ≥{state.get('_ce_votes_needed', CE_VOTES_NEEDED)} to confirm)")

            harvest = hard_locks_profit and view.mfe_r >= 1.5
            if harvest:
                # ═══ Harvest — الخروج مع ربح محقق (بدون تغيير) ═══
                mode = "HARVEST"
                for key, rkey, tag in (
                    ("pos_a", "risk_pct_a", "A"),
                    ("pos_b", "risk_pct_b", "B"),
                    ("pos_c", "risk_pct_c", "C"),
                ):
                    p = state[key]
                    if not p.get("active"):
                        continue
                    if key == "pos_a" and p.get("tp1_hit") and p.get("pnl"):
                        p["active"] = False
                        p["exit_reason"] = f"CE_{mode}"
                        events.append(f"☠️ A:CE_{mode}_KEEP_TP1")
                        continue
                    move = (view.price_c - p["entry"]) if is_long else (p["entry"] - view.price_c)
                    rr = move / risk if risk > 0 else 0
                    p["active"] = False
                    p["pnl"] = rr * state[rkey]
                    p["exit_reason"] = f"CE_{mode}"
                    events.append(f"☠️ {tag}:CE_{mode} @ {view.price_c:.2f}")
                state["pnl_pct"] = (pa.get("pnl") or 0) + (pb.get("pnl") or 0) + (pc.get("pnl") or 0)
                state["exit_reason_a"] = pa.get("exit_reason", "?")
                state["exit_reason_b"] = pb.get("exit_reason", "?")
                state["exit_reason_c"] = pc.get("exit_reason", "?")
                return events
            elif risk_cut:
                # ═══ risk_cut بدون harvest → كان المفروض يقتل بس soft exit بدأه ═══
                # لو وصلنا هنا مع risk_cut=True وبدون soft exit (fallback case)
                mode = "RISK_CUT"
                for key, rkey, tag in (
                    ("pos_a", "risk_pct_a", "A"),
                    ("pos_b", "risk_pct_b", "B"),
                    ("pos_c", "risk_pct_c", "C"),
                ):
                    p = state[key]
                    if not p.get("active"):
                        continue
                    if key == "pos_a" and p.get("tp1_hit") and p.get("pnl"):
                        p["active"] = False
                        p["exit_reason"] = f"CE_{mode}"
                        events.append(f"☠️ A:CE_{mode}_KEEP_TP1")
                        continue
                    move = (view.price_c - p["entry"]) if is_long else (p["entry"] - view.price_c)
                    rr = move / risk if risk > 0 else 0
                    p["active"] = False
                    p["pnl"] = rr * state[rkey]
                    p["exit_reason"] = f"CE_{mode}"
                    events.append(f"☠️ {tag}:CE_{mode} @ {view.price_c:.2f}")
                state["pnl_pct"] = (pa.get("pnl") or 0) + (pb.get("pnl") or 0) + (pc.get("pnl") or 0)
                state["exit_reason_a"] = pa.get("exit_reason", "?")
                state["exit_reason_b"] = pb.get("exit_reason", "?")
                state["exit_reason_c"] = pc.get("exit_reason", "?")
                return events
            else:
                events.append("🔄 CE_BODY_BUT_HOLD (fortress synthesis)")

        if view.dol_verdict == "TURTLE" and pb.get("active") and view.dol_b is not None:
            move = (view.price_c - pb["entry"]) if is_long else (pb["entry"] - view.price_c)
            rr = move / risk if risk > 0 else 0
            pb["active"] = False
            pb["pnl"] = max(0.0, rr) * state["risk_pct_b"]
            pb["exit_reason"] = "DOL_TURTLE"
            events.append("🐢 B:TURTLE_SOUP")
        elif view.dol_verdict == "EXTEND":
            if view.extend_b and pb.get("active"):
                pb["tp2_price"] = view.extend_b
                events.append(f"🚀 B:FIB_EXT→{view.extend_b:.2f}")
            if view.extend_c and pc.get("active"):
                pc["tp3_price"] = view.extend_c
                events.append(f"🚀 C:FIB_EXT→{view.extend_c:.2f}")
        elif view.dol_verdict == "WATCH" and pb.get("active") and view.dol_b is not None:
            eps = atr * 0.05
            pb["tp2_price"] = view.dol_b + eps if is_long else view.dol_b - eps
            events.append("👀 B:DOL_VELOCITY_WATCH")

        if view.phase == PHASE_EXPAN:
            for key, label in (("pos_b", "B"), ("pos_c", "C")):
                p = state[key]
                if not p.get("active"):
                    continue

                # ═══ TP1 Gate — قبل TP1 لا نحرك SL لـ B/C ═══
                # المصدر: ICT 2022 Mentorship — "Better to take part of your position off and
                # hold onto your same stops. Otherwise, if you trail you will get stopped out early"
                # + innercircletrader.net — "Stops parked exactly at the CE often get hunted on the second test"
                # التفكير: قبل TP1، مافيه ITL مؤسساتي حقيقي بعد — الصفقة لا تزال في بدايتها
                # تحريك SL فوق الدخول بـ 13 نقطة عند MFE=0.39R يقتل الصفقة على أول ردة
                # بعد TP1، يكون عندنا partial ربح محقق و ITL حقيقي — هنا بس نحرك الستوب
                tp1_reached = pa.get("tp1_hit") or state.get("mx_partial_taken")
                if not tp1_reached:
                    continue  # لا نحرك SL لـ B/C قبل TP1

                hard = view.hard_fortress
                soft = view.soft_fortress
                new_sl = p["sl"]
                reason = None
                if hard is not None:
                    # Dynamic buffer يكبر مع MFE — للـ RR الكبير 16R و 30R
                    # مصدر: ICT — trailing below previous bullish OB's low
                    # التفكير: لو MFE=13R، buffer 0.05 ATR بيمسكه الضجيج — لازم أكبر
                    # Formula: buffer = 0.05 ATR at 0R, 1.25 ATR at 3R, 3.05 ATR at 10R+
                    dynamic_buffer = atr * (0.05 + min(3.0, view.mfe_r * 0.4))
                    if is_long:
                        if hard > p["sl"] and hard < view.price_c:
                            if soft is None or hard >= soft or hard > entry:
                                new_sl = hard - dynamic_buffer
                                reason = f"ITL_HARD→{new_sl:.2f} buf={dynamic_buffer:.2f} MFE={view.mfe_r:.1f}R"
                    else:
                        dynamic_buffer = atr * (0.05 + min(1.0, view.mfe_r * 0.15))
                        if hard < p["sl"] and hard > view.price_c:
                            if soft is None or hard <= soft or hard < entry:
                                new_sl = hard + dynamic_buffer
                                reason = f"ITL_HARD→{new_sl:.2f} buf={dynamic_buffer:.2f} MFE={view.mfe_r:.1f}R"
                if reason is None and soft is not None:
                    if is_long and soft > p["sl"] and soft < view.wave_best:
                        new_sl = soft
                        reason = f"CE_SOFT→{new_sl:.2f}"
                    elif (not is_long) and soft < p["sl"] and soft > view.wave_best:
                        new_sl = soft
                        reason = f"CE_SOFT→{new_sl:.2f}"
                if reason and ((is_long and new_sl > p["sl"]) or ((not is_long) and new_sl < p["sl"])):
                    p["sl"] = new_sl
                    p["be_set"] = True
                    events.append(f"🛡️ {label}:{reason}")

            if view.extreme_exhaustion:
                bp = abs(view.price_c - view.price_o) / max(1e-12, view.price_h - view.price_l)
                for key, label in (("pos_b", "B"), (("pos_c", "C"))):
                    p = state[key]
                    if not p.get("active"):
                        continue
                    if is_long and view.price_c > view.price_o and bp > 0.5:
                        ns = view.price_l - atr * 0.05
                        if ns > p["sl"]:
                            p["sl"] = ns
                            events.append(f"⚡ {label}:CLIMAX_TRAIL→{ns:.2f}")
                    elif (not is_long) and view.price_c < view.price_o and bp > 0.5:
                        ns = view.price_h + atr * 0.05
                        if ns < p["sl"]:
                            p["sl"] = ns
                            events.append(f"⚡ {label}:CLIMAX_TRAIL→{ns:.2f}")

        return events


def _close_leg(p, state, rkey, price, is_long, reason, risk):
    p["active"] = False
    p["exit_reason"] = reason
    move = (price - p["entry"]) if is_long else (p["entry"] - price)
    rr = move / risk if risk > 0 else 0
    p["pnl"] = rr * state[rkey]


def manage_matrix_triple(c5, c1h, c4h, state, day_ctx=None):
    is_short = state["is_short"]
    is_long = not is_short
    risk = state["risk"]
    atr = state.get("atr", 1.0)
    h, l, c, o = c5["h"], c5["l"], c5["c"], c5.get("o", c5["c"])
    events: List[str] = []

    # ═══ تحميل الإعدادات حسب العملة (Multi-Asset Tuning) ═══
    # كل عملة لها سلوك مؤسساتي مختلف — ما نطبق نفس الإعدادات على الكل
    # المصادر والبيانات: انظر asset_profile.py
    profile: AssetProfile = state.get("_profile")
    if profile is None:
        symbol = state.get("symbol", "BTC")
        profile = get_asset_profile(symbol)
        state["_profile"] = profile

    # قراءة الثوابت من الـ Profile (ديناميكي حسب العملة)
    _ce_votes_needed = profile.ce_votes_needed
    _chop_minutes = profile.chop_timeout_mins
    _chop_mfe_threshold = profile.chop_mfe_threshold
    _ce_body_threshold = profile.ce_body_threshold
    _volume_multiplier = profile.volume_multiplier

    if "mind" not in state:
        state["mind"] = InstitutionalMind()
        state["market_phase"] = PHASE_ACCUM
    mind: InstitutionalMind = state["mind"]
    mind.feed(c5, c1h, c4h)
    state["candle_count"] = state.get("candle_count", 0) + 1
    days = state["candle_count"] / 288.0
    # تخزين بيانات الحجم من العقل للاستخدام في decide_and_act
    state["_mind_volumes"] = mind.volumes
    state["_ce_votes_needed"] = _ce_votes_needed
    state["_ce_body_threshold"] = _ce_body_threshold
    state["_volume_multiplier"] = _volume_multiplier

    view = mind.perceive(state, c5, day_ctx)
    state["market_phase"] = view.phase
    state["mx_mfe_r"] = view.mfe_r
    state["mx_last_impression"] = view.impression
    state["mx_narrative"] = view.narrative

    # ═══ Chop Detector — خروج لو الصفقة ميتة ═══
    # المصدر: ICT IPDA — "price delivery follows algorithmic rules, seeks liquidity"
    # + iqoption.com — "Chop markets have no liquidity, exit immediately"
    # القاعدة: لو ACCUMULATION أكتر من CHOP_MINUTES والميت MFE<CHOP_MFE_THRESHOLD = اطلع
    # ⚠️ CHOP_MINUTES و CHOP_MFE_THRESHOLD يقرآن من AssetProfile حسب العملة
    # BTC: 180min | ETH: 240min (حركة أبطأ، تحتاج وقت أطول للتنفس)
    # ⚠️ استثناء مهم: لو impression score ≥ 50 (displacement يتشكل) — لا تقتل!
    # مصدر: ICT — "Displacement is the institutional fingerprint" — لو واضح يتشكل = حياة
    # البيانات: صفقة ديسمبر 40894 كانت MFE=0.15R بعد 90 دقيقة بس impression كان يبني
    # وكبرت لـ MFE=5.6R! لذلك لازم نحسس "الحياة" مش بس الوقت
    pa, pb, pc = state["pos_a"], state["pos_b"], state["pos_c"]
    trade_minutes = state["candle_count"] * 5
    impression_score = view.impression.get("score", 0) if view.impression else 0
    if view.phase == PHASE_ACCUM and trade_minutes >= _chop_minutes and view.mfe_r < _chop_mfe_threshold and impression_score < 50:
        # الصفقة ميتة — لا سيولة، لا حركة — اطلع بأقل خسارة
        for key, rkey, tag in (("pos_a", "risk_pct_a", "A"), ("pos_b", "risk_pct_b", "B"), ("pos_c", "risk_pct_c", "C")):
            p = state[key]
            if p.get("active"):
                move = (c - p["entry"]) if (not state["is_short"]) else (p["entry"] - c)
                rr = move / risk if risk > 0 else 0
                p["active"] = False
                p["pnl"] = rr * state[rkey]
                p["exit_reason"] = "CHOP_TIMEOUT"
        state["pnl_pct"] = (pa.get("pnl") or 0) + (pb.get("pnl") or 0) + (pc.get("pnl") or 0)
        state["exit_reason_a"] = pa.get("exit_reason", "?")
        state["exit_reason_b"] = pb.get("exit_reason", "?")
        state["exit_reason_c"] = pc.get("exit_reason", "?")
        events.append(f"⏰ CHOP_TIMEOUT {trade_minutes}min ACCUM MFE={view.mfe_r:.2f}R<{_chop_mfe_threshold}R — no liquidity, exiting")
        return events, True

    # ═══ UPGRADE 3: CE Soft Exit — فحص نافذة الخروج الناعم ═══
    # مصدر: ICT Core Month 5 — "CE penetration alone is not enough for invalidation"
    # بدل القتل الفوري عند CE_RISK_CUT → نعطي السعر 6 شموع للارتداد
    # ⚠️ ما ننقل SL — SL الأصلي يبقى كـ safety net (ما أسوأ من baseline أبداً)
    # لو السعر ارتد فوق CE → نكمل الصفقة
    # لو شمعة 15M أغلقت تحت CE بجسم + حجم عالي → قتل فعلي
    ce_soft_st = state.get("_ce_soft_exit")
    if ce_soft_st and ce_soft_st.active:
        volumes_list = state.get("_mind_volumes", [])
        vol_ma10 = float(np.mean(volumes_list[-10:])) if len(volumes_list) >= 10 else 0.0
        candle_15m_ce = mind.candles_15m[-1] if mind.candles_15m else None

        action, reason = check_ce_soft_exit(
            ce_soft_st,
            candle={'o': o, 'h': h, 'l': l, 'c': c, 'v': c5.get('v', 0)},
            volume_ma10=vol_ma10,
            candle_15m=candle_15m_ce,
        )
        events.append(f"🔄 CE_SOFT_EXIT: {action}")

        if action == "RECOVERED":
            # السعر ارتد فوق CE — استعادة SL الأصلي + نكمل الصفقة
            for p, attr in [(pa, 'original_sl_a'), (pb, 'original_sl_b'), (pc, 'original_sl_c')]:
                orig_sl = getattr(ce_soft_st, attr, 0)
                if p.get("active") and orig_sl > 0:
                    p["sl"] = orig_sl
            state["_ce_soft_exit"] = None
            events.append("✅ CE_SOFT_RECOVERED: SLs restored, continuing trade")
        elif action in ("HARD_KILL", "TIMEOUT_KILL"):
            # القتل الفعلي — CE فشل رسمياً
            for key, rkey, tag in (("pos_a", "risk_pct_a", "A"), ("pos_b", "risk_pct_b", "B"), ("pos_c", "risk_pct_c", "C")):
                p = state[key]
                if not p.get("active"):
                    continue
                if key == "pos_a" and p.get("tp1_hit") and p.get("pnl"):
                    p["active"] = False
                    p["exit_reason"] = "CE_SOFT_KILL_TP1_KEPT"
                    events.append("☠️ A:CE_SOFT_KILL_TP1_KEPT")
                    continue
                move = (c - p["entry"]) if is_long else (p["entry"] - c)
                rr = move / risk if risk > 0 else 0
                p["active"] = False
                p["pnl"] = rr * state[rkey]
                p["exit_reason"] = f"CE_SOFT_{action}"
                events.append(f"☠️ {tag}:CE_SOFT_{action}")
            state["pnl_pct"] = (pa.get("pnl") or 0) + (pb.get("pnl") or 0) + (pc.get("pnl") or 0)
            state["exit_reason_a"] = pa.get("exit_reason", "?")
            state["exit_reason_b"] = pb.get("exit_reason", "?")
            state["exit_reason_c"] = pc.get("exit_reason", "?")
            state["_ce_soft_exit"] = None
            return events, True
        elif action == "CONTINUE":
            # SL بالفعل على سعر الدخول — ننتظر (نمنع CE_RISK_CUT و SL العادي)
            view.body_close_kills_ce = False
            view.wick_only_into_ce = True

    # ═══ UPGRADE 2: Fortress Grace — فحص مهلة الـ Fortress لـ B و C ═══
    # مصدر: ICT Core Month 5 & 7 — "ITL breaks can be stop hunts, not real breaks"
    # عند لمس ITL → مهلة 3 شموع (15 دقيقة) قبل الخروج
    # لو السعر رجع فوق ITL → false break → نكمل
    for leg_key, leg_tag in [("pos_b", "B"), ("pos_c", "C")]:
        grace = state.get(f"_fortress_grace_{leg_tag.lower()}")
        if grace and grace.active:
            p = state[leg_key]
            if not p.get("active"):
                state[f"_fortress_grace_{leg_tag.lower()}"] = None
                continue
            volumes_list_g = state.get("_mind_volumes", [])
            vol_ma10_g = float(np.mean(volumes_list_g[-10:])) if len(volumes_list_g) >= 10 else 0.0
            candle_15m_g = mind.candles_15m[-1] if mind.candles_15m else None

            should_exit, grace_reason = check_fortress_grace(
                grace,
                candle={'o': o, 'h': h, 'l': l, 'c': c, 'v': c5.get('v', 0)},
                volume_ma10=vol_ma10_g,
                candle_15m=candle_15m_g,
            )
            rkey = f"risk_pct_{leg_tag.lower()}"
            if should_exit:
                _close_leg(p, state, rkey, p["sl"], is_long, f"{leg_tag}_FORTRESS_GRACE_EXIT", risk)
                events.append(f"🛡️ {leg_tag}:FORTRESS_GRACE_EXIT — {grace_reason}")
                state[f"_fortress_grace_{leg_tag.lower()}"] = None
            else:
                events.append(f"🔄 {leg_tag}:FORTRESS_GRACE_CONTINUE — {grace_reason}")

    brain_events = mind.decide_and_act(state, view)
    events.extend(brain_events)

    pa, pb, pc = state["pos_a"], state["pos_b"], state["pos_c"]

    if not pa.get("active") and not pb.get("active") and not pc.get("active"):
        state["pnl_pct"] = (pa.get("pnl") or 0) + (pb.get("pnl") or 0) + (pc.get("pnl") or 0)
        state["exit_reason_a"] = pa.get("exit_reason", "?")
        state["exit_reason_b"] = pb.get("exit_reason", "?")
        state["exit_reason_c"] = pc.get("exit_reason", "?")
        return events, True

    if pa.get("active"):
        if not pa.get("tp1_hit"):
            if (is_short and h >= pa["sl"]) or (is_long and l <= pa["sl"]):
                # ═══ A-Survival — Anti-SL على A ═══
                # إذا MFE > 0.5R، الفكرة كانت ماشية — نسجّل 0.5R ربح بدل -1R كامل
                # مصدر: ICT "While moving in favor, continue to trust that move and hold"
                # + "down-closed candles should support price" — MFE<0.5R يعني لا دعم
                if risk > 0:
                    mfe_a = (pa.get("entry", 0) - pa["sl"]) / risk if is_short else (pa["sl"] - pa["entry"]) / risk
                    mfe_a = -mfe_a
                else:
                    mfe_a = 0
                wave = mind.wave_best
                if wave is None:
                    wave = pa["entry"]
                mfe_actual = ((pa["entry"] - wave) / risk) if is_short else ((wave - pa["entry"]) / risk)
                if mfe_actual >= 0.5:
                    survival_pnl = 0.5 * state["risk_pct_a"]
                    pa["active"] = False
                    pa["pnl"] = survival_pnl
                    pa["exit_reason"] = "A_SURVIVAL_50R"
                    events.append(f"🛡️ A:SURVIVAL MFE_was={mfe_actual:.2f}R SL_hit → save 0.5R = +{survival_pnl:.3f}% (vs -1.2% full SL)")
                else:
                    _close_leg(pa, state, "risk_pct_a", pa["sl"], is_long, "SL", risk)
                    events.append("❌ A:SL")
            elif pa.get("tp1"):
                if (is_short and l <= pa["tp1"]) or (is_long and h >= pa["tp1"]):
                    pa["tp1_hit"] = True
                    rr = abs(pa["tp1"] - pa["entry"]) / risk if risk else 0
                    pa["pnl"] = rr * state["risk_pct_a"]
                    pa["sl"] = pa["entry"]
                    events.append("🎯 A:TP1")
                    if pb.get("active") and not pb.get("be_set"):
                        state["mx_partial_taken"] = True
                        events.append("📣 PARTIAL_TAKEN→fortresses_active")
        else:
            if (is_short and h >= pa["sl"]) or (is_long and l <= pa["sl"]):
                pa["active"] = False
                pa["exit_reason"] = "A_TRAIL"
                events.append("🧠 A:Trail")
            else:
                # ═══ Trail لـ A بعد TP1 — خلف ITL مش ATR ضيق ═══
                # المصدر: ICT — "trailing below previous bullish OB's low" (ITL مش STL)
                # + iqoption.com: "Crypto needs 3.0× ATR trailing"
                # + blofin.com: "Swing trades — wait for +2R before trailing"
                # التفكير: ATR×0.1 طلع A عند 2.1R في صفقة 31R — trail ضيق يقتل الرابحة
                # الحل: نستخدم ITL 1H كـ trailing level (مع buffer صغير)
                # بدون ITL: نستخدم 1.5× ATR (مش 0.1×) — يعطي الصفقة مساحة تتنفس
                bp = abs(c - o) / max(1e-12, h - l)
                if bp > 0.5:
                    if is_long and c > o:
                        itl_1h = view.itl_1h
                        if itl_1h is not None and itl_1h > pa["entry"]:
                            # Trail خلف ITL 1H — مستوى مؤسساتي حقيقي
                            ns = itl_1h - atr * 0.2
                            if ns > pa["sl"]:
                                pa["sl"] = ns
                        else:
                            # بدون ITL واضح — استخدم ATR أوسع (1.5× مش 0.1×)
                            ns = l - atr * 1.5
                            if ns > pa["sl"]:
                                pa["sl"] = ns
                    elif is_short and c < o:
                        itl_1h = view.itl_1h
                        if itl_1h is not None and itl_1h < pa["entry"]:
                            ns = itl_1h + atr * 0.2
                            if ns < pa["sl"]:
                                pa["sl"] = ns
                        else:
                            ns = h + atr * 1.5
                            if ns < pa["sl"]:
                                pa["sl"] = ns

    # ═══ TP1 Gate لـ BE — B/C لا يتحولوا لـ BE إلا بعد TP1 ═══
    # المصدر: ICT 2022 Mentorship — "Better to take part of your position off and hold onto
    # your same stops. Otherwise, if you trail you will get stopped out early"
    # + ICT: "Once an ITL is created it should not be taken out" — قبل TP1 مافيه ITL مؤسساتي
    # + innercircletrader.net: "Stops parked exactly at the CE often get hunted on the second test"
    # التفكير: قبل TP1، B و C يحتفظوا بالـ SL الأصلي — يعطي الصفقة فرصة تتنفس
    # بعد TP1، نحصل على ITL حقيقي وهنا بس نفعّل be_set
    if pa.get("tp1_hit") or state.get("mx_partial_taken"):
        for p in (pb, pc):
            if p.get("active"):
                p["be_set"] = True

    if pb.get("active"):
        if pb.get("tp2_price") and view.dol_verdict not in ("WATCH", "EXTEND"):
            if (is_short and l <= pb["tp2_price"]) or (is_long and h >= pb["tp2_price"]):
                _close_leg(pb, state, "risk_pct_b", pb["tp2_price"], is_long, "TP2", risk)
                events.append("🏆 B:TP2")
        if pb.get("active") and not pb.get("be_set"):
            if (is_short and h >= pb["sl"]) or (is_long and l <= pb["sl"]):
                # ═══ B-Survival — Anti-SL على B ═══
                # نفس منطق A-Survival لكن على B (0.6% مخاطرة = 30% من الـ2%)
                wave = mind.wave_best
                if wave is None:
                    wave = pb["entry"]
                mfe_actual_b = ((pb["entry"] - wave) / risk) if is_short else ((wave - pb["entry"]) / risk)
                if mfe_actual_b >= 0.5:
                    survival_pnl = 0.3 * state["risk_pct_b"]
                    pb["active"] = False
                    pb["pnl"] = survival_pnl
                    pb["exit_reason"] = "B_SURVIVAL_30R"
                    events.append(f"🛡️ B:SURVIVAL MFE_was={mfe_actual_b:.2f}R SL_hit → save 0.3R = +{survival_pnl:.3f}% (vs -0.6% full SL)")
                else:
                    _close_leg(pb, state, "risk_pct_b", pb["sl"], is_long, "SL", risk)
                    events.append("❌ B:SL")
        elif pb.get("active") and pb.get("be_set"):
            if (is_short and h >= pb["sl"]) or (is_long and l <= pb["sl"]):
                # ═══ UPGRADE 2: Fortress Grace — مهلة هيكلية بدل الخروج الفوري ═══
                # مصدر: ICT Core Month 5 & 7 — "ITL breaks can be stop hunts, not real breaks"
                # 69% من الخاسرات كانت sweeps — السعر رجع بعد ضرب SL!
                # بدل الخروج فوراً → نعطي 3 شموع (15 دقيقة) مهلة
                grace_b = state.get("_fortress_grace_b")
                if grace_b and grace_b.active:
                    # المهلة فعّالة — لا نخرج، الفحص يتم في بداية manage_matrix_triple
                    events.append(f"🔄 B:FORTRESS_GRACE_ACTIVE (SL at {pb['sl']:.2f} touched, grace protecting)")
                else:
                    # بدء مهلة جديدة
                    itl_level = view.hard_fortress if view.hard_fortress else pb["sl"]
                    state["_fortress_grace_b"] = start_fortress_grace(itl_level, is_long, max_candles=3)
                    events.append(f"🛡️ B:FORTRESS_GRACE_STARTED ITL={itl_level:.2f} (3-candle grace instead of instant exit)")
            else:
                # بعد 3R، B يستخدم 4H ITL — مساحة أكبر لـ 10R+
                # مصدر: ICT — manage on 4-hour for swing, Keep perspective 5-day horizon
                # بعد 5R، يتطلب كسر قوي جداً (body>=0.8 + disp>=70) — لا يخرج على ذيل صغير
                if view.scale_shift_active:
                    use_reader = mind.reader_4h if view.mfe_r >= 3.0 else mind.reader_1h
                    intact, reason = use_reader.is_structure_intact(is_long, c)
                    if not intact:
                        check_candle = c4h if view.mfe_r >= 3.0 else c1h
                        if check_candle:
                            bp = abs(check_candle['c']-check_candle['o'])/max(1e-12, check_candle['h']-check_candle['l'])
                            imp = displacement_impression(mind.candles_5m, is_long)
                            if view.mfe_r >= 5.0:
                                # للـ RR الكبير — يتطلب body>=0.8 و disp>=70
                                is_opp = (is_long and check_candle['c']<check_candle['o'] and bp>=0.8 and imp.get("score",0)>=70) or ((not is_long) and check_candle['c']>check_candle['o'] and bp>=0.8 and imp.get("score",0)>=70)
                            else:
                                is_opp = (is_long and check_candle['c']<check_candle['o'] and bp>=0.6) or ((not is_long) and check_candle['c']>check_candle['o'] and bp>=0.6)
                            if is_opp:
                                _close_leg(pb, state, "risk_pct_b", c, is_long, f"B_{'4H' if view.mfe_r>=3.0 else '1H'}_STRUCT_SCALE_HOLD_LONGER_STRONG", risk)
                                events.append(f"🧱 B:{'4H' if view.mfe_r>=3.0 else '1H'} {reason[:30]} SCALE_SHIFT_HOLD_LONGER_STRONG MFE={view.mfe_r:.1f}R")
                            else:
                                events.append(f"🔄 B:{'4H' if view.mfe_r>=3.0 else '1H'} STL_HOLD SCALE_SHIFT_HOLD_LONGER_STRONG - protecting big RR {view.mfe_r:.1f}R")
                else:
                    intact, reason = mind.reader_1h.is_structure_intact(is_long, c)
                    if not intact:
                        imp = displacement_impression(mind.candles_5m, is_long)
                        if imp.get("score", 0) >= 50 or _body_pct(c5) >= 0.7:
                            _close_leg(pb, state, "risk_pct_b", c, is_long, "B_STRUCT", risk)
                            events.append(f"🧱 B:{reason[:40]}")
                        else:
                            events.append("🔄 B:STL_HOLD")

    if pc.get("active"):
        if pc.get("tp3_price") and view.dol_verdict not in ("WATCH",):
            if (is_short and l <= pc["tp3_price"]) or (is_long and h >= pc["tp3_price"]):
                _close_leg(pc, state, "risk_pct_c", pc["tp3_price"], is_long, "TP3_MEGA", risk)
                events.append("💎 C:TP3")
        if pc.get("active") and not pc.get("be_set"):
            if (is_short and h >= pc["sl"]) or (is_long and l <= pc["sl"]):
                # ═══ C-Survival — Anti-SL على C ═══
                # نفس منطق A-Survival لكن على C (0.2% مخاطرة = 10% من الـ2%)
                wave = mind.wave_best
                if wave is None:
                    wave = pc["entry"]
                mfe_actual_c = ((pc["entry"] - wave) / risk) if is_short else ((wave - pc["entry"]) / risk)
                if mfe_actual_c >= 0.5:
                    survival_pnl = 0.3 * state["risk_pct_c"]
                    pc["active"] = False
                    pc["pnl"] = survival_pnl
                    pc["exit_reason"] = "C_SURVIVAL_30R"
                    events.append(f"🛡️ C:SURVIVAL MFE_was={mfe_actual_c:.2f}R SL_hit → save 0.3R = +{survival_pnl:.3f}% (vs -0.2% full SL)")
                else:
                    _close_leg(pc, state, "risk_pct_c", pc["sl"], is_long, "SL", risk)
                    events.append("❌ C:SL")
        elif pc.get("active") and pc.get("be_set"):
            # ═══ Ratchet ITL Shield + Midnight Fortress لـ C ═══
            # المصدر: ICT — "Once an ITL is created it should not be taken out"
            # + xs.com ICT Trading: "Daily Open = institutional floor for the day"
            # + proptradingvibes.com: "In rally days, price never breaks Daily Open"
            # القاعدة: بعد TP1، C يتحول لـ ratchet — الستوب ما يحق يرجع للوراء
            # MFE≥5R: SL خلف آخر 15M ITL أو Midnight Open (أيهما أعلى للشراء)
            # MFE≥3R: SL خلف آخر 5M ITL
            # مبدأ الـ Ratchet: كل تحريك للأمام فقط — لا رجوع
            if not (is_short and h >= pc["sl"]) and not (is_long and l <= pc["sl"]):
                # C ما زال حي — طبّق Ratchet
                ratchet_sl = pc["sl"]  # البداية = الـ SL الحالي
                ratchet_reason = None

                if view.mfe_r >= 5.0:
                    # ═══ MFE≥5R: Trail خلف 15M ITL + Midnight Open ═══
                    # هذا مستوى مؤسساتي قوي — يحمي الأرباح المتضخمة
                    itl_15m = view.itl_15
                    midnight = day_ctx.get("day_open") if day_ctx else None

                    if is_long:
                        candidates_ratchet = []
                        if itl_15m is not None and itl_15m < c and itl_15m > pc["entry"]:
                            candidates_ratchet.append(itl_15m - atr * 0.2)
                        if midnight is not None and midnight < c and midnight > pc["entry"]:
                            candidates_ratchet.append(midnight - atr * 0.1)
                        if candidates_ratchet:
                            best = max(candidates_ratchet)
                            if best > ratchet_sl:
                                ratchet_sl = best
                                ratchet_reason = f"C:RATCHET_5R SL→{ratchet_sl:.2f} (15M_ITL/Midnight MAX)"
                    else:
                        candidates_ratchet = []
                        if itl_15m is not None and itl_15m > c and itl_15m < pc["entry"]:
                            candidates_ratchet.append(itl_15m + atr * 0.2)
                        if midnight is not None and midnight > c and midnight < pc["entry"]:
                            candidates_ratchet.append(midnight + atr * 0.1)
                        if candidates_ratchet:
                            best = min(candidates_ratchet)
                            if best < ratchet_sl:
                                ratchet_sl = best
                                ratchet_reason = f"C:RATCHET_5R SL→{ratchet_sl:.2f} (15M_ITL/Midnight MIN)"

                elif view.mfe_r >= 3.0:
                    # ═══ MFE≥3R: Trail خلف آخر 5M ITL ═══
                    # مصدر: ICT — "trailing below previous bullish OB's low"
                    itl_5m = view.itl_15  # أقرب ITL من 15M reader
                    if is_long and itl_5m is not None and itl_5m < c and itl_5m > pc["entry"]:
                        candidate = itl_5m - atr * 0.15
                        if candidate > ratchet_sl:
                            ratchet_sl = candidate
                            ratchet_reason = f"C:RATCHET_3R SL→{ratchet_sl:.2f} (5M ITL)"
                    elif (not is_long) and itl_5m is not None and itl_5m > c and itl_5m < pc["entry"]:
                        candidate = itl_5m + atr * 0.15
                        if candidate < ratchet_sl:
                            ratchet_sl = candidate
                            ratchet_reason = f"C:RATCHET_3R SL→{ratchet_sl:.2f} (5M ITL)"

                # تطبيق الـ Ratchet (ما يحق يرجع للوراء)
                if ratchet_reason:
                    pc["sl"] = ratchet_sl
                    events.append(f"🛡️ {ratchet_reason} MFE={view.mfe_r:.1f}R")

            if (is_short and h >= pc["sl"]) or (is_long and l <= pc["sl"]):
                # ═══ UPGRADE 2: Fortress Grace — مهلة هيكلية لـ C أيضاً ═══
                # نفس منطق B — 69% من خسائر C كانت sweeps
                grace_c = state.get("_fortress_grace_c")
                if grace_c and grace_c.active:
                    events.append(f"🔄 C:FORTRESS_GRACE_ACTIVE (SL at {pc['sl']:.2f} touched, grace protecting)")
                else:
                    itl_level = view.hard_fortress if view.hard_fortress else pc["sl"]
                    state["_fortress_grace_c"] = start_fortress_grace(itl_level, is_long, max_candles=3)
                    events.append(f"🛡️ C:FORTRESS_GRACE_STARTED ITL={itl_level:.2f} (3-candle grace instead of instant exit)")
            elif days >= 5:
                _close_leg(pc, state, "risk_pct_c", c, is_long, "5DAY", risk)
                events.append("📅 C:5DAY")
            else:
                if view.scale_shift_active:
                    # لو MFE>=5R، استخدم Daily low/high كـ fortress — مساحة لـ 16R/30R
                    if view.mfe_r >= 5.0 and day_ctx and day_ctx.get("day_low") is not None:
                        if is_long:
                            d_low = day_ctx["day_low"]
                            if d_low and d_low < c and d_low > pc["sl"]:
                                pc["sl"] = d_low - atr * 0.2
                                events.append(f"🛡️ C:DAILY_LOW→{pc['sl']:.2f} MFE={view.mfe_r:.1f}R LARGE_RR_16_30")
                        else:
                            d_high = day_ctx["day_high"]
                            if d_high and d_high > c and d_high < pc["sl"]:
                                pc["sl"] = d_high + atr * 0.2
                                events.append(f"🛡️ C:DAILY_HIGH→{pc['sl']:.2f} MFE={view.mfe_r:.1f}R LARGE_RR")
                        events.append(f"🔄 C:DAILY_HOLD LARGE_RR MFE={view.mfe_r:.1f}R - capturing big RR")
                    else:
                        intact4, r4 = mind.reader_4h.is_structure_intact(is_long, c)
                        if not intact4:
                            if c4h:
                                bp_4h = abs(c4h['c']-c4h['o'])/max(1e-12, c4h['h']-c4h['l'])
                                is_opp = (is_long and c4h['c']<c4h['o'] and bp_4h>=0.5) or ((not is_long) and c4h['c']>c4h['o'] and bp_4h>=0.5)
                                if is_opp:
                                    _close_leg(pc, state, "risk_pct_c", c, is_long, "C_4H_BREAK_SCALE", risk)
                                    events.append(f"🧱 C:4H {r4[:30]} SCALE_SHIFT")
                                else:
                                    events.append("🔄 C:4H STL_HOLD SCALE_SHIFT")
                else:
                    intact4, r4 = mind.reader_4h.is_structure_intact(is_long, c)
                    if not intact4:
                        imp = displacement_impression(mind.candles_5m, is_long)
                        if imp.get("score", 0) >= 50 or _body_pct(c5) >= 0.7:
                            _close_leg(pc, state, "risk_pct_c", c, is_long, "C_4H_BREAK", risk)
                            events.append(f"🧱 C:{r4[:40]}")
                        else:
                            events.append("🔄 C:STL_HOLD_4H")

    done = not pa.get("active", False) and not pb.get("active", False) and not pc.get("active", False)
    if done:
        state["pnl_pct"] = (pa.get("pnl") or 0) + (pb.get("pnl") or 0) + (pc.get("pnl") or 0)
        state["exit_reason_a"] = pa.get("exit_reason", "?")
        state["exit_reason_b"] = pb.get("exit_reason", "?")
        state["exit_reason_c"] = pc.get("exit_reason", "?")
    return events, done

def entry_matrix_filters(is_long, entry_price, bias, midnight_open, strict_midnight=False, hard_midnight=False):
    return entry_accumulation_filters(
        is_long, entry_price, bias, midnight_open,
        hard_midnight=hard_midnight or strict_midnight,
    )


# ═══════════════════════════════════════════════════════════════════════════
# V3.0 HONEST — Hybrid Entry Selection + Honest Limit Fill (لا fallback)
# ═══════════════════════════════════════════════════════════════════════════
# المصادر:
# - innercircletrader.net FVG: "wait for price to return to the FVG before entering"
#   => إن لم يعد السعر للـFVG فلا دخول. هذا انضباط ICT.
# - innercircletrader.net FVG Consequent Encroachment (CE): منتصف الفجوة = مستوى إعادة التوازن.
#
# القاعدة الذهبية V3.0: لا تُحسب صفقة إلا إذا لمس السعر سعر الدخول فعلاً.
# - compute_hybrid_entry: LONG→IOFED=fvg_top, SHORT→IOFED=fvg_bot (الحافة القريبة الصحيحة).
#   [V2.4 كان يعكسها → دخول بعيد لا يلمسه السعر → صفقات وهمية]
# - process_limit_order_state: لمس → fill. timeout → إلغاء صادق.
#   أُلغي MARKET_FALLBACK_TP1_HIT (كان يخترع صفقات من أوامر لم تُملأ = جذر الـbug).
#
# ملاحظة: الـrunner الأساسي (run_matrix_only_dec2023.py V3.0) لا يستخدم هاتين الدالتين —
# يطبّق نفس المنطق الصادق inline مع دخول CE. هذه الدوال مُصلّحة للتوافق المستقبلي.


def compute_hybrid_entry(
    is_long: bool,
    fvg_top: float,
    fvg_bot: float,
    signal_price: float,
    atr: float,
    original_entry_ce: float,
    sl: float,
) -> Tuple[float, str, bool]:
    """
    V3.0 — Honest Hybrid Entry Selection (مُصحّح).
    Returns: (smart_entry, entry_type, use_limit)

    IOFED "just inside the edge of the FVG" (مصدر: ICT IOFED):
    الحافة التي يعود إليها السعر أولاً أثناء إعادة التوازن:
      - LONG  → fvg_top (السعر فوق الفجوة، يرتد للأسفل فيدخلها من حدّها الأعلى)
      - SHORT → fvg_bot (السعر تحت الفجوة، يرتد للأعلى فيدخلها من حدّها الأسفل)
    [V2.4 كان يعكس هذا → دخول بعيد لا يلمسه السعر → صفقات وهمية]

    Threshold 5×ATR: ≤ 5×ATR → Market؛ > 5×ATR → Limit.
    ملاحظة: هذا اختيار السعر فقط. ملء الـlimit يجب أن يتم بصدق (لمس فعلي).
    """
    if is_long:
        iofed = fvg_top
    else:
        iofed = fvg_bot

    threshold_atr = atr * 5.0 if atr > 0 else abs(signal_price - sl) * 0.5
    distance = abs(signal_price - iofed)

    if distance <= threshold_atr:
        return iofed, "MARKET_IOFED_NEAR", False
    else:
        return iofed, "LIMIT_IOFED_NEAR", True


def process_limit_order_state(active: dict, row: dict) -> bool:
    """
    V3.0 — HONEST Limit Order State Processor (لا fallback).
    Returns: True إذا الصفقة لا تزال نشطة، False إذا أُلغيت.

    القاعدة الذهبية: لا تُملأ إلا إذا لمس مدى الشمعة سعر الدخول فعلاً.
    - أُلغي MARKET_FALLBACK_TP1_HIT: كان يخترع صفقة من أمر لم يُملأ بمجرد
      وصول السعر للهدف — هذا كان جذر الـbug (يحسب أرباحاً لم تحدث).
    - اللمس فقط يُملأ. Timeout → إلغاء صادق (لا ربح لا خسارة).
    """
    if not active or not active.get('is_limit_order', False):
        return bool(active)

    if active['pos_a'].get('entry_filled', True):
        return True

    entry_price = active['pos_a']['entry']
    is_long_trade = not active['is_short']
    tp1_price = active['pos_a'].get('tp1')

    entry_touched = row['l'] <= entry_price <= row['h']

    if entry_touched:
        active['pos_a']['entry_filled'] = True
        active['pos_b']['entry_filled'] = True
        active['pos_c']['entry_filled'] = True
        active.setdefault('events', []).append(f"{row['dt']} ✅ LIMIT_FILLED @ {entry_price:.2f}")
        return True

    # لا MARKET_FALLBACK — إن لم يُلمس الدخول، ننتظر timeout ثم نُلغي صادقاً
    active['limit_candles_left'] = active.get('limit_candles_left', 72) - 1
    if active['limit_candles_left'] <= 0:
        active.setdefault('events', []).append(f"{row['dt']} ❌ LIMIT_TIMEOUT_CANCELLED (price never reached entry)")
        active['cancelled_limit'] = True
        return False

    return True


def manage_matrix_triple_v24(c5, c1h, c4h, state, day_ctx=None):
    """
    V2.4 wrapper around manage_matrix_triple.
    يضيف: V2.4-specific logging وTP1_HIT tracking
    """
    events, closed = manage_matrix_triple(c5, c1h, c4h, state, day_ctx=day_ctx)

    if closed:
        state['exit_entry_type'] = state.get('entry_type', 'UNKNOWN')

    return events, closed
