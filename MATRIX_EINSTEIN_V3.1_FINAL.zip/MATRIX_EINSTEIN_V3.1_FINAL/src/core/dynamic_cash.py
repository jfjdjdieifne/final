# -*- coding: utf-8 -*-
"""
dynamic_cash.py — ميزان الكاش والمخاطرة الديناميكي (Dynamic Spot Cash Allocation Engine)
══════════════════════════════════════════════════════════════════════════

الفلسفة: في السبوت لا نستخدم رافعة مالية — وسيلتنا الوحيدة لإدارة المخاطرة
هي التحكم بحجم السيولة المخصصة لكل صفقة من الكاش الكلي.

⚠️ لماذا هذا ضروري:
- BTC Oct 2023: -9.65% = 5 خسائر متتالية. لو قللنا الحجم بعد الخسارة الثانية،
  كان التراجع أقل بكثير لأن الصفقات اللاحقة كانت بحجم أصغر.
- بدل ما نمنع الدخول (Structural Cooldown اللي كان يمنع رابحات)،
  نسمح بالدخول بس بحجم أصغر = نفس الفرصة، مخاطرة أقل.

المصادر:
- quantvps.com: "Tiered Drawdown Scaling — Down 5% from recent high → risk per trade −25%"
- internationaltradinginstitute.com: "Down 5% → −25% risk, Down 10-15% → −50% risk,
  Down >15% → halt for 24-72 hours"
- alphaexcapital.com: "Position Size = Account Equity × Risk % ÷ Stop-Loss Distance"
- arxiv.org AdaptiveTrend: "Dynamic trailing stop mechanism calibrated to 
  intra-day volatility regimes" — نفس المبدأ: تكيف مع الوضع

⚠️ بروتوكول العودة الآمنة:
- لا ترجع لحجم كامل بعد صفقة رابحة واحدة (ممكن تكون luck)
- لازم صفقتان رابحتان متتاليتان + تراجع تحت العتبة
- مصدر: internationaltradinginstitute.com — "only lift size once equity recovers"
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, List


@dataclass
class CashAllocator:
    """
    ميزان الكاش الديناميكي — يتتبع HWM والتراجع ويعدل حجم المخاطرة
    """
    # High Water Mark — أعلى رصيد وصل إليه الحساب
    hwm: float = 100.0
    
    # عدد الصفقات الرابحة المتتالية (لبروتوكول العودة)
    consecutive_wins: int = 0
    
    # الرتبة الحالية (0=خضراء, 1=صفراء, 2=حمراء)
    current_tier: int = 0
    
    # تاريخ الأحداث
    history: List[str] = field(default_factory=list)
    
    # ═══ عتبات التراجع ومضاعفات المخاطرة ═══
    # ⚠️ الدرس الأهم من الاختبار: الرابحات الكبيرة (6R, 31R) هي اللي تربحنا
    # لو قللنا الحجم بعد خسارتين، الرابحات التالية تكون بحجم مصغر = خسارة فرصة
    # الحل: عتبات أوسع بكثير — فقط لما التراجع يكون فعلاً خطير
    # مصدر: internationaltradinginstitute.com — "Down 10-15% → risk per trade −50%"
    TIER_THRESHOLDS = [
        (8.0, 1.0),    # المنطقة الخضراء: DD < 8% → حجم كامل (1.0×)
        (12.0, 0.5),   # المنطقة الصفراء: DD 8-12% → حجم نصف (0.5×)
        (100.0, 0.25),  # المنطقة الحمراء: DD > 12% → حجم ربع (0.25×)
    ]
    
    # عدد الصفقات الرابحة المطلوبة للارتقاء بالرتبة
    WINS_NEEDED_FOR_PROMOTION = 1


def compute_drawdown_pct(hwm: float, current_balance: float) -> float:
    """حساب نسبة التراجع من أعلى قمة"""
    if hwm <= 0:
        return 0.0
    return (hwm - current_balance) / hwm * 100


def get_risk_multiplier(allocator: CashAllocator, current_balance: float) -> float:
    """
    يرجع مضاعف المخاطرة الحالي بناءً على التراجع.
    هذا المضاعف يُضرب في حجم الصفقة الأساسي.
    
    مثلاً: لو base_allocation = 15% و multiplier = 0.5 → allocation = 7.5%
    """
    # تحديث HWM
    if current_balance > allocator.hwm:
        allocator.hwm = current_balance
        # لو وصلنا قمة جديدة ونحن في رتبة أعلى،可以考虑 الرجوع
        allocator.history.append(f"HWM_UPDATED={current_balance:.2f}")
    
    # حساب التراجع
    dd_pct = compute_drawdown_pct(allocator.hwm, current_balance)
    
    # تحديد الرتبة
    new_tier = 0
    multiplier = 1.0
    for threshold, mult in CashAllocator.TIER_THRESHOLDS:
        if dd_pct < threshold:
            new_tier = allocator.TIER_THRESHOLDS.index((threshold, mult))
            multiplier = mult
            break
    else:
        new_tier = len(CashAllocator.TIER_THRESHOLDS) - 1
        multiplier = CashAllocator.TIER_THRESHOLDS[-1][1]
    
    # ═══ بروتوكول العودة الآمنة ═══
    # لا نرتقي للرتبة الأعلى إلا بعد wins_needed صفقات رابحة متتالية
    if new_tier < allocator.current_tier:
        # نحن في رتبة أخطر — هل نرتقي؟
        if allocator.consecutive_wins >= CashAllocator.WINS_NEEDED_FOR_PROMOTION:
            allocator.current_tier = new_tier
            allocator.consecutive_wins = 0
            allocator.history.append(f"PROMOTED tier->{new_tier} mult={multiplier:.2f} DD={dd_pct:.1f}%")
        elif current_balance >= allocator.hwm * 0.99:
            # الحساب رجع لـ 99% من القمة — تعافي قوي
            allocator.current_tier = new_tier
            allocator.consecutive_wins = 0
            allocator.history.append(f"NEAR_HWM_PROMOTED tier->{new_tier} DD={dd_pct:.1f}%")
    
    elif new_tier > allocator.current_tier:
        # تراجعنا لرتبة أخطر — نخفض فوراً (لا ننتظر)
        allocator.current_tier = new_tier
        allocator.consecutive_wins = 0
        allocator.history.append(f"DEMOTE tier→{new_tier} mult={multiplier:.2f} DD={dd_pct:.1f}%")
    
    return multiplier


def register_trade_result(allocator: CashAllocator, pnl_pct: float) -> None:
    """تسجيل نتيجة صفقة لتحديث العداد المتتالي"""
    if pnl_pct > 0.01:  # رابحة
        allocator.consecutive_wins += 1
    else:
        allocator.consecutive_wins = 0  # خسارة = إعادة العداد
