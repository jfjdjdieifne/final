# -*- coding: utf-8 -*-
"""
asset_profile.py — إعدادات ديناميكية لكل عملة (Multi-Asset Parameter Tuning)
══════════════════════════════════════════════════════════════════════════

الفلسفة: BTC و ETH مو كائن واحد — كل واحدة لها سلوك مؤسساتي مختلف:
- BTC: حجم سيولة ضخم، فلاتر السبت فعالة (لا سيولة IPDA بنهاية الأسبوع)،
  حساسية الحجم أقل لأن الحجم الأساسي عالي
- ETH: سيولة أقل، حركة أبطأ (محتاجة وقت أطول تتنفس)، فلتر السبت مضر
  (يفقد صفقات 6R+)، حساسية الحجم أعلى لأن الحجم الأساسي أقل

المصادر:
- ictkillzone.com: "ICT IPDA — Interbank Price Delivery Algorithm operates on banking hours"
- xs.com ICT Trading: "Weekend crypto lacks institutional liquidity" — لكن ETH سلوكه مختلف!
- البيانات المُتحقق منها: فلتر السبت وفّر ~8% على BTC لكن خسّر +5.66% على ETH (Oct)
- iqoption.com: "Crypto needs 3.0× ATR trailing" — لكن ETH يحتاج أوسع من BTC
- blofin.com: "Swing trades — wait for +2R before trailing" — ETH يحتاج وقت أطول

⚠️ ممنوع إعدادات عامة — كل ثابت لازم يكون مدروس ومبرر ببيانات أو مصدر
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class AssetProfile:
    """
    إعدادات مُفصّلة لكل عملة — يقرأها الكود ديناميكياً
    كل قيمة مبررة بمصدر أو بيانات مُتحقق منها
    """
    name: str = "BTC"

    # ═══ فلتر السبت ═══
    # BTC: فعّال — وفّر ~8% بمنع 4 صفقات خاسرة
    # ETH: مضر — خسّر +5.66% بمنع صفقة Oct entry=1598.4 (MFE=6.21R)
    block_saturday: bool = True

    # ═══ عتبة الحجم للتصويت الثلاثي ═══
    # BTC: 1.5× — الحجم الأساسي ضخم، الـ spike لازم يكون واضح
    # ETH: 2.1× — الحجم الأساسي أضعف، لازم spike أكبر ليكون مؤسساتي حقيقي
    # مصدر: iqoption.com "Crypto volume confirms institutional participation"
    volume_multiplier: float = 1.5

    # ═══ وقت الانتظار للتذبذب (Chop Detector) ═══
    # BTC: 180 دقيقة — كافي لرصد الحركة
    # ETH: 240 دقيقة — حركة أبطأ، لازم وقت أطول (بيانات: Dec ETH تحتاج >180min)
    chop_timeout_mins: int = 180

    # ═══ عتبة MFE للـ Chop Detector ═══
    # نفس القيمة للعملتين — تحت 0.3R = فعلاً ميت
    chop_mfe_threshold: float = 0.3

    # ═══ عدد الأصوات المطلوبة لإبطال CE ═══
    # BTC: 2 من 3 — المعيار الذهبي
    # ETH: 2 من 3 — نفس الشي، لكن الحجم يتطلب multiplier أعلى كتعويض
    ce_votes_needed: int = 2

    # ═══ عتبة جسم الشمعة للتصويت ═══
    # نفس القيمة — 0.65 = جسم قوي
    ce_body_threshold: float = 0.65

    # ═══ نسبة تخصيص الكاش (Risk Allocation) ═══
    # BTC: 15% من الكاش للصفقة (سيولة عالية)
    # ETH: 12% — سيولة أقل، أحجام أصغر
    base_allocation: float = 0.15

    # ═══ ATR multiplier للـ Trail ═══
    # BTC: 1.5× — حركة أسرع
    # ETH: 2.0× — حركة أبطأ، لازم مساحة أكبر
    atr_trail_mult: float = 1.5

    # ═══ عتبة الحجم لـ Turtle Soup Re-Entry ═══
    # BTC: 1.5× متوسط الحجم — يكفي لتأكيد كنس مؤسساتي
    # ETH: 2.0× — لازم يكون أوضح بسبب السيولة الأقل
    sweep_volume_mult: float = 1.5

    # ═══ عتبة Wick Ratio لـ Turtle Soup ═══
    # نفس القيمة — 0.60 = ذيل واضح = sweep
    # مصدر: ictkillzone.com — "wait for the sweep candle to close back inside the prior range"
    sweep_wick_ratio: float = 0.60


# ═══════════════════════════════════════════════════════════════
# المصنع — يعطي الإعدادات المناسبة بناءً على اسم العملة
# ═══════════════════════════════════════════════════════════════

def get_asset_profile(symbol: str) -> AssetProfile:
    """
    يتعرف على العملة تلقائياً ويُرجع الإعدادات المناسبة.
    مدعوم: BTC, ETH — أي شيء آخر يأخذ إعدادات BTC كافتراضي.
    """
    symbol_upper = (symbol or "BTC").upper().replace("USDT", "").strip()

    if symbol_upper == "ETH":
        return AssetProfile(
            name="ETH",
            # فلتر السبت مضر لـ ETH — البيانات تثبت: Oct خسر +5.66%
            block_saturday=False,
            # الحجم الأساسي أضعف — لازم spike أكبر ليكون مؤسساتي
            volume_multiplier=2.1,
            # حركة أبطأ — منحها وقت أطول للتنفس
            chop_timeout_mins=240,
            chop_mfe_threshold=0.3,
            ce_votes_needed=2,
            ce_body_threshold=0.65,
            # سيولة أقل — أحجام أصغر
            base_allocation=0.12,
            # مساحة أكبر للـ trail
            atr_trail_mult=2.0,
            # الحجم لازم يكون أوضح
            sweep_volume_mult=2.0,
            sweep_wick_ratio=0.60,
        )
    else:
        # BTC (الافتراضي)
        return AssetProfile(
            name="BTC",
            block_saturday=True,
            volume_multiplier=1.2,  # القيمة الأصلية المُتحقق منها — 1.5 كانت تقتل رابحات
            chop_timeout_mins=180,
            chop_mfe_threshold=0.3,
            ce_votes_needed=2,
            ce_body_threshold=0.65,
            base_allocation=0.15,
            atr_trail_mult=1.5,
            sweep_volume_mult=1.5,
            sweep_wick_ratio=0.60,
        )
