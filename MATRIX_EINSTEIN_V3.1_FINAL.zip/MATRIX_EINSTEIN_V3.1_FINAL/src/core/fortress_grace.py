# -*- coding: utf-8 -*-
"""
fortress_grace.py — مهلة الـ Fortress الهيكلية التفاعلية (The Fortress Grace Period)
══════════════════════════════════════════════════════════════════════════

الفلسفة المؤسساتية (ICT Core Content - Month 5 & 7):
─────────────────────────────────────────────────────
عندما يتحرك السعر في اتجاهك، يتحرك الـ SL خلف الـ ITL.
المشكلة: بمجرد ملامسة السعر للـ ITL (حتى بذيل شمعة)، يخرج البوت فوراً.
صانع السعر يقوم بـ "كنس سيولة سريع تحت الـ ITL" (Stops Hunt)
→ البوت يخرج → السعر يطير للأعلى بدونك!

الحل: البوت يعطي السعر "مهلة هيكلية تفاعلية" يفحص فيها:
1. هل الاختراق بذيول فقط (Wicks) أم بإغلاق الجسم (Body Close)؟
2. هل حجم الكسر ضعيف (غير حقيقي) أم صاروخي (بيع مؤسساتي)؟
3. هل السعر رجع فوق الـ ITL خلال 15 دقيقة؟

القواعد:
- مهلة 3 شموع 5M (15 دقيقة) بعد أول ملامسة للـ ITL
- طالما الإغلاق فوق ITL (ذيول فقط) → الصفقة مستمرة
- إغلاق جسم تحت ITL بنسبة > 50% + حجم ضعيف → كسر وهمي، تمديد المهلة
- إغلاق جسم تحت ITL + حجم صاروخي → بيع مؤسساتي حقيقي → خروج فوري
- السعر يرجع فوق ITL → false break → إلغاء المهلة

مصدر: ICT — "down-closed candles should support price"
مصدر: ICT — "Once an ITL is created it should not be taken out" (لكن الكنس يحدث!)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Tuple
import numpy as np


@dataclass
class FortressGraceState:
    """
    تتبع حالة مهلة الـ Fortress
    """
    active: bool = False
    itl_level: float = 0.0
    is_long: bool = True
    candles_elapsed: int = 0
    max_candles: int = 3  # 15 دقيقة
    extensions_used: int = 0
    max_extensions: int = 1  # تمديد واحد فقط (شمعتين إضافيتين)
    broken_by_body: bool = False
    broken_by_volume: bool = False
    restored: bool = False  # السعر رجع فوق ITL


def start_fortress_grace(
    itl_level: float,
    is_long: bool,
    max_candles: int = 3,
) -> FortressGraceState:
    """
    بدء مهلة الـ Fortress عند أول ملامسة لـ ITL
    """
    return FortressGraceState(
        active=True,
        itl_level=itl_level,
        is_long=is_long,
        max_candles=max_candles,
    )


def check_fortress_grace(
    state: FortressGraceState,
    candle: dict,
    volume_ma10: float = 0.0,
    candle_15m: Optional[dict] = None,
) -> Tuple[bool, str]:
    """
    فحص مهلة الـ Fortress — يرجع (should_exit, reason)

    شروط الخروج:
    - إغلاق جسم 15M تحت ITL بنسبة > 50% + حجم عالي → خروج فوري
    - إغلاق جسم 5M تحت ITL + حجم ضعيف → كسر وهمي، تمديد
    - السعر رجع فوق ITL → إلغاء المهلة
    - انتهت المهلة بدون رجوع → خروج

    Args:
        state: حالة المهلة
        candle: شمعة 5M الحالية {o, h, l, c, v}
        volume_ma10: متوسط حجم آخر 10 شموع 5M
        candle_15m: شمعة 15M الحالية (اختياري) للفحص الأدق
    """
    if not state.active:
        return False, "GRACE_NOT_ACTIVE"

    state.candles_elapsed += 1
    itl = state.itl_level
    is_long = state.is_long
    o, h, l, c = candle['o'], candle['h'], candle['l'], candle['c']
    v = candle.get('v', 0)
    rng = max(1e-12, h - l)

    # ═══ 1. فحص رجوع السعر فوق ITL → False Break ═══
    if is_long:
        if c > itl and l <= itl:
            # السعر نزل تحت ITL بس أغلق فوقه — ذيل فقط = كنس وهمي
            state.restored = True
            state.active = False
            return False, f"FORTRESS_RESTORED: wick below ITL={itl:.2f} but close={c:.2f}>ITL — false break, continuing trade"
    else:
        if c < itl and h >= itl:
            state.restored = True
            state.active = False
            return False, f"FORTRESS_RESTORED: wick above ITL={itl:.2f} but close={c:.2f}<ITL — false break, continuing trade"

    # ═══ 2. فحص إغلاق الجسم ═══
    if is_long:
        body_below_itl = c < itl
        body_below_pct = (itl - c) / max(1e-12, abs(c - o)) if abs(c - o) > 0 else 0
    else:
        body_above_itl = c > itl
        body_below_pct = (c - itl) / max(1e-12, abs(c - o)) if abs(c - o) > 0 else 0

    if is_long and c < itl:
        # ═══ الإغلاق تحت ITL — فحص الحجم ═══
        vol_ratio = v / volume_ma10 if volume_ma10 > 0 else 1.0

        # ═══ 2a. فحص شمعة 15M (أدق) ═══
        if candle_15m is not None:
            c15_close = candle_15m['c']
            c15_open = candle_15m['o']
            c15_rng = max(1e-12, candle_15m['h'] - candle_15m['l'])
            c15_body_pct = abs(c15_close - c15_open) / c15_rng

            if c15_close < itl and c15_body_pct > 0.50:
                # شمعة 15M أغلقت تحت ITL بجسم > 50%
                if vol_ratio > 1.5:
                    # حجم صاروخي → بيع مؤسساتي حقيقي
                    state.broken_by_body = True
                    state.broken_by_volume = True
                    state.active = False
                    return True, (
                        f"FORTRESS_BROKEN: 15M body close={c15_close:.2f}<ITL={itl:.2f} "
                        f"body_pct={c15_body_pct:.0%} vol={vol_ratio:.1f}× — "
                        f"بيع مؤسساتي حقيقي، خروج فوري"
                    )

        # ═══ 2b. فحص حجم الكسر ═══
        if vol_ratio < 1.0 and volume_ma10 > 0:
            # حجم الكسر ضعيف (أقل من المتوسط) → كسر وهمي
            if state.extensions_used < state.max_extensions:
                state.extensions_used += 1
                state.max_candles += 2  # تمديد شمعتين
                return False, (
                    f"FORTRESS_EXTEND: body below ITL but LOW vol={vol_ratio:.1f}×<1.0 — "
                    f"كسر وهمي، تمديد المهلة +2 شموع (ext={state.extensions_used}/{state.max_extensions})"
                )
            else:
                # استنفدنا التمديدات — بس الحجم ضعيف يعني مو بيع حقيقي
                # نستنى كمان شوي
                return False, f"FORTRESS_WEAK_VOL_WAIT: vol={vol_ratio:.1f}×<1.0 but no more extensions"

        elif vol_ratio >= 1.5:
            # حجم صاروخي → بيع مؤسساتي حقيقي
            state.broken_by_body = True
            state.broken_by_volume = True
            state.active = False
            return True, (
                f"FORTRESS_BROKEN: body close={c:.2f}<ITL={itl:.2f} "
                f"vol={vol_ratio:.1f}×(≥1.5) — بيع مؤسساتي حقيقي، خروج فوري"
            )

    elif (not is_long) and c > itl:
        # ═══ نفس المنطق معكوس لـ SHORT ═══
        vol_ratio = v / volume_ma10 if volume_ma10 > 0 else 1.0

        if candle_15m is not None:
            c15_close = candle_15m['c']
            c15_open = candle_15m['o']
            c15_rng = max(1e-12, candle_15m['h'] - candle_15m['l'])
            c15_body_pct = abs(c15_close - c15_open) / c15_rng

            if c15_close > itl and c15_body_pct > 0.50:
                if vol_ratio > 1.5:
                    state.broken_by_body = True
                    state.broken_by_volume = True
                    state.active = False
                    return True, (
                        f"FORTRESS_BROKEN: 15M body close={c15_close:.2f}>ITL={itl:.2f} "
                        f"body_pct={c15_body_pct:.0%} vol={vol_ratio:.1f}× — "
                        f"شراء مؤسساتي حقيقي، خروج فوري"
                    )

        if vol_ratio < 1.0 and volume_ma10 > 0:
            if state.extensions_used < state.max_extensions:
                state.extensions_used += 1
                state.max_candles += 2
                return False, (
                    f"FORTRESS_EXTEND: body above ITL but LOW vol={vol_ratio:.1f}×<1.0 — "
                    f"كسر وهمي، تمديد المهلة"
                )
        elif vol_ratio >= 1.5:
            state.broken_by_body = True
            state.broken_by_volume = True
            state.active = False
            return True, (
                f"FORTRESS_BROKEN: body close={c:.2f}>ITL={itl:.2f} "
                f"vol={vol_ratio:.1f}×(≥1.5) — شراء مؤسساتي حقيقي، خروج فوري"
            )

    # ═══ 3. فحص انتهاء المهلة ═══
    if state.candles_elapsed >= state.max_candles:
        # المهلة انتهت بدون رجوع — ITL فعلاً مكسور
        if is_long and c < itl:
            state.active = False
            return True, f"FORTRESS_TIMEOUT: {state.candles_elapsed} candles below ITL={itl:.2f} — confirming exit"
        elif (not is_long) and c > itl:
            state.active = False
            return True, f"FORTRESS_TIMEOUT: {state.candles_elapsed} candles above ITL={itl:.2f} — confirming exit"
        else:
            # السعر رجع فوق/تحت ITL أثناء المهلة — لا خروج
            state.restored = True
            state.active = False
            return False, f"FORTRESS_RECOVERED: price back above/below ITL after grace period"

    return False, f"FORTRESS_GRACE_CONTINUE: {state.candles_elapsed}/{state.max_candles} candles"
