# -*- coding: utf-8 -*-
"""
entry_confirmation.py — شمعة تأكيد الدخول التفاعلية (Contextual Entry Confirmation Candle)
══════════════════════════════════════════════════════════════════════════

الفلسفة المؤسساتية (ICT 2022 Mentorship Episode 13 & 26):
─────────────────────────────────────────────────────────
في النسخة الحالية، بمجرد لمس السعر لمنطقة الـ CE يتم تفعيل أمر الشراء ماركت فوراً.
المشكلة: التفعيل يتم والسعر يهبط بعنف (Falling Knives) → SL يضرب قبل الارتداد.

الحل الذكي: البوت ينتظر لمس CE ثم يتحول لـ "مستشعر الرفض المؤسساتي"
للتأكد من أن صانع السعر يمتص العقود ولا يكسر الهيكل.

الشروط الثلاثة:
1. ميزان إغلاق شمعة التأكيد (Adaptive Body Close Gate)
2. بصمة الزخم والانعكاس اللحظي (Intraday Displacement Trigger)
3. ميزان التكيف مع تذبذب السوق (Volatility-Based Confirmation)

⚠️ تعديل تقني: بما أن البيانات المتاحة 5M (ليس 1M)، تم تكييف شروط
الـ Displacement Trigger لتعمل على فريم 5M مع معايير أشد صرامة.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, List, Tuple
import numpy as np


@dataclass
class ConfirmationState:
    """
    آلة حالة لتأكيد الدخول — تتبع كل شمعة بعد لمس CE
    """
    awaiting: bool = False
    ce_level: float = 0.0
    is_long: bool = True
    candles_checked: int = 0
    max_candles: int = 6  # 30 دقيقة على 5M
    volumes: List[float] = field(default_factory=list)
    high_atr: bool = False  # نظام الزخم
    prev_high: float = 0.0  # High الشمعة السابقة (لـ MSS)
    prev_low: float = 0.0   # Low الشمعة السابقة
    touch_candle_idx: int = 0  # شمعة اللمس
    rejected: bool = False
    reject_reason: str = ""
    confirmed: bool = False
    confirm_reason: str = ""


def start_confirmation(
    ce_level: float,
    is_long: bool,
    touch_idx: int = 0,
    max_candles: int = 6,
) -> ConfirmationState:
    """
    بدء وضع انتظار التأكيد بعد لمس CE
    """
    return ConfirmationState(
        awaiting=True,
        ce_level=ce_level,
        is_long=is_long,
        touch_candle_idx=touch_idx,
        max_candles=max_candles,
    )


def check_entry_confirmation(
    state: ConfirmationState,
    candle: dict,
    atr: float,
    atr_history: Optional[List[float]] = None,
) -> Tuple[bool, bool, str]:
    """
    فحص شمعة التأكيد — يرجع (confirmed, rejected, reason)

    المعايير الثلاثة:
    1. Adaptive Body Close Gate: رفض لو الجسم أغلق تحت CE بنسبة ≥ 0.35
    2. Displacement Trigger: شمعة صاعدة + حجم > 1.3× MA(10) + اختراق High السابق
    3. Volatility-Based: ATR عالي → يكفي إغلاق فوق CE | ATR منخفض → لازم تأكيد كامل
    """
    if not state.awaiting:
        return False, False, "NOT_AWAITING"

    state.candles_checked += 1

    o = candle['o']
    h = candle['h']
    l = candle['l']
    c = candle['c']
    v = candle.get('v', 0)
    ce = state.ce_level
    is_long = state.is_long
    rng = max(1e-12, h - l)

    # ═══ تحديد نظام الزخم (Volatility Regime) ═══
    if atr_history and len(atr_history) >= 10:
        atr_ma = float(np.mean(atr_history[-10:]))
        state.high_atr = atr_ma > 0 and atr > atr_ma * 1.3
    else:
        state.high_atr = False

    # ═══ تخزين الحجم ═══
    if v > 0:
        state.volumes.append(float(v))
        if len(state.volumes) > 60:
            state.volumes = state.volumes[-60:]

    if is_long:
        # ═══ 1. فحص الإغلاق فوق CE — التأكيد الأساسي (LONG) ═══
        # الفلسفة: لو السعر لمس CE وأغلق فوقه → الدعم صمد → دخول
        # مصدر: ICT — "CE is where institutional orders are placed"
        # لو الجسم أغلق تحت CE بنسبة عالية ≥ 0.50 → رفض (كسر حقيقي)
        body_below_ce = max(0, (ce - c) / rng)

        # رفض: كسر حقيقي (جسم تحت CE بنسبة ≥ 0.50)
        if body_below_ce >= 0.50:
            state.rejected = True
            state.reject_reason = (
                f"BODY_REJECTION: body_below_ce={body_below_ce:.2f}≥0.50 "
                f"CE={ce:.2f} close={c:.2f} — كسر حقيقي وليس امتصاص"
            )
            return False, True, state.reject_reason

        # ═══ قبول: الإغلاق فوق CE → الدعم صمد ═══
        if c > ce:
            state.confirmed = True
            state.confirm_reason = (
                f"CONFIRMED: close={c:.2f}>CE={ce:.2f} — "
                f"CE support held, entering trade"
            )
            return True, False, state.confirm_reason

        # تحديث بيانات الشمعة السابقة

    else:
        # ═══ SHORT — نفس المنطق معكوس ═══
        body_above_ce = max(0, (c - ce) / rng)

        # رفض: كسر حقيقي (جسم فوق CE بنسبة ≥ 0.50)
        if body_above_ce >= 0.50:
            state.rejected = True
            state.reject_reason = (
                f"BODY_REJECTION: body_above_ce={body_above_ce:.2f}≥0.50 "
                f"CE={ce:.2f} close={c:.2f} — كسر حقيقي"
            )
            return False, True, state.reject_reason

        # ═══ قبول: الإغلاق تحت CE → المقاومة صمدت ═══
        if c < ce:
            state.confirmed = True
            state.confirm_reason = (
                f"CONFIRMED: close={c:.2f}<CE={ce:.2f} — "
                f"CE resistance held, entering trade"
            )
            return True, False, state.confirm_reason

    # ═══ مهلة زمنية ═══
    if state.candles_checked >= state.max_candles:
        state.rejected = True
        state.reject_reason = (
            f"CONFIRMATION_TIMEOUT: {state.candles_checked} شموع بدون تأكيد — "
            f"السوق متردد، لا دخول"
        )
        return False, True, state.reject_reason

    return False, False, f"AWAITING_CONFIRMATION ({state.candles_checked}/{state.max_candles})"
