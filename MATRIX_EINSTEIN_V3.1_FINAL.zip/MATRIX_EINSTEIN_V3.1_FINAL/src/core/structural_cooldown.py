# -*- coding: utf-8 -*-
"""
structural_cooldown.py — فلتر الحظر الهيكلي المتتالي (Spot Structural Cooldown Engine)
══════════════════════════════════════════════════════════════════════════

الفلسفة من مصادر ICT:
- ICT Seek and Destroy Profile: "Cardinal rule: you do not trade before 
  the news release" — نفس المبدأ: لا تتداول لما البيئة مش واضحة
- ICT Core Content Month 7: السوق يمر بـ 4 مراحل دورية — Accumulation → 
  Manipulation → Distribution → Expansion
- innercircletrader.net: "Seek and Destroy describes a Friday pattern where 
  price hunts both the weekly high and low before settling"

⚠️ لماذا هذا الفلتر ضروري:
- بيانات BTC أكتوبر 2023: 5 خسائر متتالية = -10% من الحساب
- لو منعنا الدخول بعد الخسارة الثانية، كنا وفّرنا 3 صفقات = ~6%
- السبب: السوق كان في مرحلة Seek & Destroy — صعود وهبوط متناوب

⚠️ الفرق عن Chop Detector:
- Chop Detector: يقتل صفقة مفتوحة بعد 180/240 دقيقة بدون حركة
- Cooldown: يمنع فتح صفقات جديدة بعد خسائر متتالية

🛡️ شروط التفعيل (3 شروط لازم 2 من 3):
1. خسارتان متتاليتان كاملتان (full SL hit) خلال 72 ساعة
2. ATR Ratio < 0.80 (تذبذب ضيق = بيئة تلاعب)
3. تناوب هيكلي (Structural Whipsaw): خسارة long ثم short أو العكس

مصادر:
- innercircletrader.net: Seek and Destroy Friday profile
- tradingfinder.com: "S&D profile causes price to sweep both sides"
- internationaltradinginstitute.com: "cut risk after equity drawdown and 
  halt after a sequence of losses; only lift size once equity recovers"
- quantvps.com: "Tiered Drawdown Scaling — Down 5% from recent high → 
  risk per trade −25%"
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Tuple
import time


@dataclass
class CooldownState:
    """حالة الحظر الهيكلي — تتبع الخسائر والأحداث"""
    # تاريخ آخر خسارتين كاملتين
    last_loss_ts: List[int] = field(default_factory=list)  # timestamps of last full SL hits
    last_loss_directions: List[bool] = field(default_factory=list)  # True=long, False=short
    
    # حالة الحظر
    cooldown_active: bool = False
    cooldown_start_ts: int = 0
    cooldown_duration_hours: int = 48  # افتراضي
    
    # تاريخ فحص التعافي
    last_health_check_ts: int = 0
    health_check_failures: int = 0  # عدد مرات فشل فحص التعافي
    
    # تتبع ATR
    atr_history: List[float] = field(default_factory=list)  # آخر 14 يوم ATR


def should_enter_cooldown(
    state: CooldownState,
    current_ts: int,
    current_atr: Optional[float] = None,
    atr_14d_avg: Optional[float] = None,
) -> Tuple[bool, str]:
    """
    يقرر هل ندخل في حظر هيكلي بناءً على الشروط.
    
    ⚠️ في الكريبتو سبوت، الصفقات متباعدة زمنياً (كل 2-7 أيام).
    لذلك نستخدم معيار "آخر 3 صفقات" بدل نافذة زمنية ضيقة.
    
    الشروط (لازم شرط واحد فقط — خسارتان كاملتان كافية للتفعيل):
    - الأساسي: خسارتان كاملتان من آخر 3 صفقات
    - تعزيز: Whipsaw (اتجاهين مختلفين) → حظر أطول
    - تعزيز: ATR ضعيف → حظر أطول
    
    ⚠️ مدة الحظر: 72 ساعة افتراضي (3 أيام) — في الكريبتو سبوت 
    الصفقات متباعدة فـ 24 ساعة مش كافية.
    
    مصدر: internationaltradinginstitute.com — "halt after a sequence of losses"
    + بيانات BTC Oct: 5 خسائر متتالية كل 2-5 أيام = -10%
    """
    # ═══ الشرط الأساسي: 3 خسائر من آخر 4 صفقات ═══
    # ⚠️ لازم 3 خسائر (مش 2) — خسارتان طبيعي بالتداول
    # 3 خسائر = بيئة مش طبيعية = Seek & Destroy
    if len(state.last_loss_ts) < 3:
        return False, ""
    
    recent = state.last_loss_ts[-4:]  # آخر 4 خسائر
    recent_dirs = state.last_loss_directions[-4:] if len(state.last_loss_directions) >= 3 else []
    
    # لازم 3 خسائر على الأقل من آخر 4
    if len(recent) >= 3:
        time_span_days = (recent[-1] - recent[-3]) / (1000 * 3600 * 24)
        
        extra_reasons = []
        duration = 72  # 72 ساعة = 3 أيام
        
        # تعزيز 1: Whipsaw
        has_whipsaw = False
        if len(recent_dirs) >= 3:
            for i in range(len(recent_dirs)-1):
                if recent_dirs[i] != recent_dirs[i+1]:
                    has_whipsaw = True
                    break
        if has_whipsaw:
            extra_reasons.append("WHIPSAW")
            duration = 96
        
        # تعزيز 2: ATR ضعيف
        if current_atr is not None and atr_14d_avg is not None and atr_14d_avg > 0:
            atr_ratio = current_atr / atr_14d_avg
            if atr_ratio < 0.85:
                extra_reasons.append(f"ATR_LOW={atr_ratio:.2f}")
                duration = max(duration, 96)
        
        reason = f"3+_LOSSES span={time_span_days:.0f}d"
        if extra_reasons:
            reason += " | " + " | ".join(extra_reasons)
        
        return True, f"{reason} | DURATION={duration}h"
    
    return False, ""


def check_market_health(
    current_atr: Optional[float],
    atr_14d_avg: Optional[float],
    weekly_high_broken: bool = False,
) -> Tuple[bool, str]:
    """
    فحص سلامة السوق بعد انتهاء فترة الحظر.
    لازم يتحقق شرط واحد على الأقل للسماح بالعودة.
    
    مصدر: ICT — "Displacement confirms institutional return"
    + quantvps.com — "Only lift size once equity recovers"
    
    Returns: (is_healthy, reason)
    """
    checks = []
    
    # فحص 1: ATR عاد للمتوسط أو أعلى (زخم رجع)
    if current_atr is not None and atr_14d_avg is not None and atr_14d_avg > 0:
        atr_ratio = current_atr / atr_14d_avg
        if atr_ratio >= 1.0:
            checks.append(f"ATR_OK={atr_ratio:.2f}≥1.0")
    
    # فحص 2: كسر هيكلي صعودي (أغلق فوق قمة الأسبوع)
    if weekly_high_broken:
        checks.append("WEEKLY_HIGH_BROKEN")
    
    # لازم شرط واحد على الأقل
    if checks:
        return True, " | ".join(checks)
    
    return False, "NO_HEALTH_SIGNAL"


def register_loss(state: CooldownState, ts: int, is_long: bool) -> None:
    """تسجيل خسارة كاملة (full SL hit) في حالة الحظر"""
    state.last_loss_ts.append(ts)
    state.last_loss_directions.append(is_long)
    
    # الاحتفاظ بآخر 5 خسائر فقط
    if len(state.last_loss_ts) > 5:
        state.last_loss_ts = state.last_loss_ts[-5:]
        state.last_loss_directions = state.last_loss_directions[-5:]


def activate_cooldown(state: CooldownState, ts: int, duration_hours: int = 24) -> None:
    """تفعيل الحظر الهيكلي — 24 ساعة للسبوت (مش 48) لأن الصفقات متباعدة"""
    state.cooldown_active = True
    state.cooldown_start_ts = ts
    state.cooldown_duration_hours = duration_hours
    state.health_check_failures = 0


def is_in_cooldown(state: CooldownState, current_ts: int) -> Tuple[bool, str]:
    """
    هل نحن حالياً في فترة حظر؟
    إذا انتهت المدة، نفحص سلامة السوق:
    - صحية → نلغي الحظر
    - غير صحية → نمدد 24 ساعة
    """
    if not state.cooldown_active:
        return False, ""
    
    elapsed_hours = (current_ts - state.cooldown_start_ts) / (1000 * 3600)
    
    if elapsed_hours < state.cooldown_duration_hours:
        remaining = state.cooldown_duration_hours - elapsed_hours
        return True, f"COOLDOWN_{remaining:.0f}h_LEFT"
    
    # انتهت المدة — لكن ما نلغي الحظر عمياء!
    # لازم فحص سلامة السوق
    return True, "COOLDOWN_EXPIRED_NEED_HEALTH_CHECK"


def try_lift_cooldown(
    state: CooldownState,
    current_ts: int,
    current_atr: Optional[float] = None,
    atr_14d_avg: Optional[float] = None,
    weekly_high_broken: bool = False,
) -> Tuple[bool, str]:
    """
    محاولة رفع الحظر بعد فحص سلامة السوق.
    Returns: (lifted, reason)
    """
    is_healthy, health_reason = check_market_health(
        current_atr, atr_14d_avg, weekly_high_broken
    )
    
    if is_healthy:
        state.cooldown_active = False
        state.health_check_failures = 0
        return True, f"COOLDOWN_LIFTED: {health_reason}"
    else:
        # مد 24 ساعة إضافية
        state.health_check_failures += 1
        state.cooldown_start_ts = current_ts  # إعادة تشغيل المؤقت
        state.cooldown_duration_hours = 12  # مدة تمديد أقصر (12 ساعة مش 24)
        return False, f"COOLDOWN_EXTENDED_24h: {health_reason} (fail #{state.health_check_failures})"
