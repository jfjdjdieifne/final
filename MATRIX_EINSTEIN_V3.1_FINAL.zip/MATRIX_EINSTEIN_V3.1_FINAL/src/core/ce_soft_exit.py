# -*- coding: utf-8 -*-
"""
ce_soft_exit.py — نافذة الخروج الناعم للـ CE التفاعلية (Adaptive CE Soft Exit Window)
══════════════════════════════════════════════════════════════════════════

الفلسفة المؤسساتية (ICT Core Content - Month 5):
──────────────────────────────────────────────────
تفعيل CE_RISK_CUT كان يخرجنا بخسائر صغيرة، لكن 88% من صفقات ETH المقتولة
عادت لتطير للأعلى فور خروجنا!

المشكلة: صانع السعر يقوم بـ "إعادة توازن ذيل الشمعة" (Wick Rebalance)
→ يهبط بسرعة ليملأ الفراغ السعري للـ CE → يعود فوراً للصعود.
البوت كان يعتبر أي لمسة للـ CE بمثابة فشل → يخرج بخوف.

الحل الذكي: بدل القتل الفوري، يتحول البوت لـ "مستشعر إعادة التوازن المرن":
1. ي نقل الستوب لوس لمستوى الـ CE (خسارة شبه معدومة)
2. يمنح السعر 6 شمعات 5M (30 دقيقة) لعمل Rebalance
3. لو السعر ارتد فوق CE → إلغاء حالة الخطر تماماً + استعادة الـ SL
4. القتل الفعلي فقط لو شمعة 15M أغلقت بجسمها تحت CE + حجم عالي

مصدر: ICT — "CE penetration alone is not enough for invalidation" (arongroups.co)
مصدر: ICT — "Wick rebalance is normal, body close is the diagnostic" (thesimpleict.com)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Tuple
import numpy as np


@dataclass
class CESoftExitState:
    """
    تتبع حالة الخروج الناعم للـ CE
    """
    active: bool = False
    ce_level: float = 0.0
    original_sl_a: float = 0.0  # SL الأصلي قبل النقل
    original_sl_b: float = 0.0
    original_sl_c: float = 0.0
    is_long: bool = True
    candles_elapsed: int = 0
    max_candles: int = 6  # 30 دقيقة
    recovered: bool = False  # السعر رجع فوق CE
    hard_killed: bool = False  # تم القتل الفعلي


def start_ce_soft_exit(
    ce_level: float,
    is_long: bool,
    current_sl_a: float = 0.0,
    current_sl_b: float = 0.0,
    current_sl_c: float = 0.0,
    max_candles: int = 6,
) -> CESoftExitState:
    """
    بدء نافذة الخروج الناعم — نقل SL لـ CE بدل القتل الفوري
    """
    return CESoftExitState(
        active=True,
        ce_level=ce_level,
        is_long=is_long,
        original_sl_a=current_sl_a,
        original_sl_b=current_sl_b,
        original_sl_c=current_sl_c,
        max_candles=max_candles,
    )


def check_ce_soft_exit(
    state: CESoftExitState,
    candle: dict,
    volume_ma10: float = 0.0,
    candle_15m: Optional[dict] = None,
) -> Tuple[str, str]:
    """
    فحص نافذة الخروج الناعم — يرجع (action, reason)

    الإجراءات:
    - "RECOVERED": السعر رجع فوق CE → إلغاء حالة الخطر + استعادة SL
    - "HARD_KILL": شمعة 15M أغلقت تحت CE بجسم + حجم عالي → قتل فوري
    - "CONTINUE": استمرار الانتظار
    - "TIMEOUT_KILL": انتهت المهلة بدون رجوع → قتل

    Args:
        state: حالة الخروج الناعم
        candle: شمعة 5M الحالية {o, h, l, c, v}
        volume_ma10: متوسط حجم آخر 10 شموع
        candle_15m: شمعة 15M (اختياري) للفحص الأدق
    """
    if not state.active:
        return "NOT_ACTIVE", "CE_SOFT_NOT_ACTIVE"

    state.candles_elapsed += 1
    ce = state.ce_level
    is_long = state.is_long
    o, h, l, c = candle['o'], candle['h'], candle['l'], candle['c']
    v = candle.get('v', 0)
    rng = max(1e-12, h - l)

    # ═══ 1. فحص رجوع السعر فوق CE → إلغاء حالة الخطر ═══
    if is_long:
        if c > ce:
            # السعر ارتد فوق CE — إعادة التوازن نجحت!
            state.recovered = True
            state.active = False
            return "RECOVERED", (
                f"CE_SOFT_RECOVERED: close={c:.2f}>CE={ce:.2f} after {state.candles_elapsed} candles — "
                f"rebalance successful, restoring SL and continuing trade"
            )
    else:
        if c < ce:
            state.recovered = True
            state.active = False
            return "RECOVERED", (
                f"CE_SOFT_RECOVERED: close={c:.2f}<CE={ce:.2f} after {state.candles_elapsed} candles — "
                f"rebalance successful, restoring SL and continuing trade"
            )

    # ═══ 2. فحص القتل الفعلي — شمعة 15M ═══
    if candle_15m is not None:
        c15_close = candle_15m['c']
        c15_open = candle_15m['o']
        c15_rng = max(1e-12, candle_15m['h'] - candle_15m['l'])
        c15_body_pct = abs(c15_close - c15_open) / c15_rng if c15_rng > 0 else 0

        # هل الجسم أغلق تحت/فوق CE بنسبة > 50%؟
        if is_long and c15_close < ce and c15_body_pct > 0.50:
            # فحص الحجم — هل هو صاروخي؟
            vol_ratio = v / volume_ma10 if volume_ma10 > 0 else 1.0
            if vol_ratio >= 1.5:
                # تأكيد مؤسساتي — CE فعلاً ميت
                state.hard_killed = True
                state.active = False
                return "HARD_KILL", (
                    f"CE_HARD_KILL: 15M body close={c15_close:.2f}<CE={ce:.2f} "
                    f"body_pct={c15_body_pct:.0%} vol={vol_ratio:.1f}×(≥1.5) — "
                    f"OB فشل رسمياً، خروج نهائي"
                )

        elif (not is_long) and c15_close > ce and c15_body_pct > 0.50:
            vol_ratio = v / volume_ma10 if volume_ma10 > 0 else 1.0
            if vol_ratio >= 1.5:
                state.hard_killed = True
                state.active = False
                return "HARD_KILL", (
                    f"CE_HARD_KILL: 15M body close={c15_close:.2f}>CE={ce:.2f} "
                    f"body_pct={c15_body_pct:.0%} vol={vol_ratio:.1f}×(≥1.5) — "
                    f"OB فشل رسمياً، خروج نهائي"
                )

    # ═══ 3. فحص انتهاء المهلة ═══
    if state.candles_elapsed >= state.max_candles:
        # 30 دقيقة مرت بدون رجوع فوق CE
        if is_long and c < ce:
            state.hard_killed = True
            state.active = False
            return "TIMEOUT_KILL", (
                f"CE_SOFT_TIMEOUT: {state.candles_elapsed} candles below CE={ce:.2f} "
                f"current={c:.2f} — OB لم يتعافى، خروج نهائي"
            )
        elif (not is_long) and c > ce:
            state.hard_killed = True
            state.active = False
            return "TIMEOUT_KILL", (
                f"CE_SOFT_TIMEOUT: {state.candles_elapsed} candles above CE={ce:.2f} "
                f"current={c:.2f} — OB لم يتعافى، خروج نهائي"
            )
        else:
            # السعر رجع فوق/تحت CE في اللحظة الأخيرة
            state.recovered = True
            state.active = False
            return "RECOVERED", (
                f"CE_SOFT_LAST_MINUTE_RECOVERY: price back above/below CE at timeout"
            )

    return "CONTINUE", (
        f"CE_SOFT_WAIT: {state.candles_elapsed}/{state.max_candles} candles, "
        f"price={'below' if (is_long and c < ce) else 'above' if (not is_long and c > ce) else 'at'} CE"
    )
