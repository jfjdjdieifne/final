#!/usr/bin/env python3
"""Fair comparison: HONEST vs MODIFIED across months — same runner logic, different core files.
Runs as a script that takes the version path as argument."""
import csv, datetime, sys, os, time
from collections import defaultdict

if len(sys.argv) < 3:
    print("Usage: python compare_test.py <VERSION> <MONTH> [SYMBOL]")
    print("Example: python compare_test.py RELEASE 2023-08 BTC")
    sys.exit(1)

VERSION = sys.argv[1]  # "HONEST" or "MODIFIED_V3" or "RELEASE"
MONTH = sys.argv[2]
SYMBOL = sys.argv[3] if len(sys.argv) > 3 else "BTC"

BASE = os.path.dirname(os.path.abspath(__file__))
if VERSION == "HONEST":
    SRC = os.path.join(BASE, 'HONEST', 'final_matrix_einstein_V3_HONEST')
elif VERSION == "MODIFIED_V3":
    SRC = os.path.join(BASE, 'MODIFIED_V3')
elif VERSION == "RELEASE":
    SRC = os.path.join(BASE, 'RELEASE', 'final_matrix_einstein_V3')
else:
    print(f"Unknown version: {VERSION}")
    sys.exit(1)

sys.path.insert(0, os.path.join(SRC, 'src', 'core'))
sys.path.insert(0, os.path.join(SRC, 'src', 'runners'))

from ict_sessions import classify_session
try:
    from ict_sessions import is_saturday_ny
except ImportError:
    is_saturday_ny = lambda ts: False  # fallback for old versions
from ict_layered_brain import read_bias, read_narrative, read_trigger, build_plan
from ict_math_engine import detect_ict_three_candle_swings
from ict_matrix_ride import manage_matrix_triple, entry_accumulation_filters, get_ny_day_key
from asset_profile import get_asset_profile
from structural_cooldown import CooldownState, should_enter_cooldown, register_loss, activate_cooldown, is_in_cooldown, try_lift_cooldown
from dynamic_cash import CashAllocator, get_risk_multiplier, register_trade_result

# ═══ UPGRADE 1: Entry Confirmation — معطل حالياً ═══
# السبب: CE Soft Exit + Fortress Grace بيحموا الصفقات عند الخروج بشكل أفضل
# تأكيد الدخول بيمنع صفقات رابحة (من +12.64% لـ +6.71% على BTC Dec)
# لو حابب تفعّله: غيّر ENTRY_CONFIRMATION_ENABLED = True
ENTRY_CONFIRMATION_ENABLED = False
if ENTRY_CONFIRMATION_ENABLED:
    from entry_confirmation import start_confirmation, check_entry_confirmation

BTC_PATH = os.path.join(BASE, 'data', 'BTCUSDT_5m_2017-09-01_to_2025-09-23.csv')
ETH_PATH = os.path.join(BASE, 'data', 'eth_3_5', 'ETHUSDT_5m.csv')
RISK = 0.02

def load_data(path, months):
    rows = []
    with open(path) as f:
        r = csv.DictReader(f)
        for row in r:
            dt_str = row.get('datetime', '')
            if not dt_str:
                vals = list(row.values())
                dt_str = vals[1] if len(vals) > 1 else ''
            if not any(dt_str.startswith(m) for m in months): continue
            dt_str = dt_str[:16]
            try: dt = datetime.datetime.strptime(dt_str, '%Y-%m-%d %H:%M')
            except: continue
            rows.append({
                'ts': int(dt.replace(tzinfo=datetime.timezone.utc).timestamp() * 1000),
                'dt': dt_str, 'o': float(row['open']), 'h': float(row['high']),
                'l': float(row['low']), 'c': float(row['close']), 'v': float(row['volume']),
            })
    return rows

def slice_data(rows, end_idx, lookback):
    s = max(0, end_idx - lookback + 1)
    ch = rows[s:end_idx + 1]
    return {'timestamps': [r['ts'] for r in ch], 'opens': [r['o'] for r in ch],
            'highs': [r['h'] for r in ch], 'lows': [r['l'] for r in ch],
            'closes': [r['c'] for r in ch], 'volumes': [r['v'] for r in ch]}

def aggregate(data, tf):
    n = len(data['closes'])
    ratio = tf // 5
    if n < ratio: return None
    out = {'timestamps': [], 'opens': [], 'highs': [], 'lows': [], 'closes': [], 'volumes': []}
    for i in range(n // ratio):
        a, b = i * ratio, (i + 1) * ratio
        out['timestamps'].append(data['timestamps'][a])
        out['opens'].append(data['opens'][a])
        out['highs'].append(max(data['highs'][a:b]))
        out['lows'].append(min(data['lows'][a:b]))
        out['closes'].append(data['closes'][b - 1])
        out['volumes'].append(sum(data['volumes'][a:b]))
    return out

def daily_ctx(rows, idx):
    by = defaultdict(lambda: {'h': -1e18, 'l': 1e18, 'o': None})
    for r in rows[:idx + 1]:
        k = get_ny_day_key(r['ts'])
        if by[k]['o'] is None: by[k]['o'] = r['o']
        by[k]['h'] = max(by[k]['h'], r['h'])
        by[k]['l'] = min(by[k]['l'], r['l'])
    cur = get_ny_day_key(rows[idx]['ts'])
    completed = sorted(d for d in by if d < cur)
    ranges = [by[d]['h'] - by[d]['l'] for d in completed[-10:]]
    return ranges, by[cur]['o'], by[cur]['h'], by[cur]['l'], cur

def midnight_open(rows, idx):
    cur = get_ny_day_key(rows[idx]['ts'])
    for i in range(idx, -1, -1):
        if get_ny_day_key(rows[i]['ts']) != cur:
            return rows[i + 1]['o'] if i + 1 <= idx else rows[idx]['o']
    return rows[0]['o']

def run(symbol, rows, month):
    profile = get_asset_profile(symbol)
    cooldown = CooldownState()  # ═══ Structural Cooldown State ═══
    cash_alloc = CashAllocator()  # ═══ Dynamic Cash Allocator ═══
    start_idx = next((i for i, r in enumerate(rows) if r['dt'].startswith(month)), None)
    if start_idx is None: return None
    EXEC = {'LONDON_KILLZONE', 'NY_AM_KILLZONE', 'NY_PM_KILLZONE'}
    balance = 100.0
    trades = []
    active = None
    pending = None
    cancelled = []
    entered = set()
    c1 = c4 = 0
    rejected = 0
    scans = 0

    for idx in range(start_idx, len(rows)):
        row = rows[idx]
        if not row['dt'].startswith(month): break
        c1 += 1; c4 += 1
        if active:
            c5 = {'o': row['o'], 'h': row['h'], 'l': row['l'], 'c': row['c'], 'v': row.get('v', 0)}
            c1h = c4h = None
            if c1 >= 12 and idx >= 12:
                ch = rows[idx-11:idx+1]
                c1h = {'o': ch[0]['o'], 'h': max(x['h'] for x in ch), 'l': min(x['l'] for x in ch), 'c': row['c']}
                c1 = 0
            if c4 >= 48 and idx >= 48:
                ch = rows[idx-47:idx+1]
                c4h = {'o': ch[0]['o'], 'h': max(x['h'] for x in ch), 'l': min(x['l'] for x in ch), 'c': row['c']}
                c4 = 0
            hist, d_o, d_h, d_l, dk = daily_ctx(rows, idx)
            ctx = {'hist_ranges': hist, 'day_open': d_o, 'day_high': d_h, 'day_low': d_l, 'day_key': dk,
                   'setup_start': active.get('setup_start'), 'setup_end': active.get('setup_end')}
            is_short = active['is_short']
            entry = active['pos_a']['entry']
            if is_short: fav = entry - row['l']; adv = row['h'] - entry
            else: fav = row['h'] - entry; adv = entry - row['l']
            if active['risk'] > 0:
                active['mfe_r'] = max(active.get('mfe_r', 0), fav / active['risk'])
                active['mae_r'] = max(active.get('mae_r', 0), adv / active['risk'])
            events, closed = manage_matrix_triple(c5, c1h, c4h, active, day_ctx=ctx)
            if events:
                active['events'] = active.get('events', []) + events
            if closed:
                pnl = active.get('pnl_pct') or 0
                _was_short = active.get('is_short', False)  # حفظ قبل ما يمسح
                usd = balance * pnl / 100
                balance += usd
                active['exit_time'] = row['dt']
                active['pnl_pct'] = pnl
                active['pnl_dollar'] = usd
                trades.append(active)
                active = None
                
                # ═══ Dynamic Cash Allocation — تسجيل النتيجة ═══
                register_trade_result(cash_alloc, pnl)
                
                # ═══ Structural Cooldown — تسجيل الخسائر (معطل) ═══
                # لو الصفقة خسرت أكتر من -0.5% = خسارة كاملة
                # مصدر: ICT Seek and Destroy — "consecutive losses = chop environment"
                if pnl < -0.5:
                    register_loss(cooldown, row['ts'], not _was_short)
                    # فحص هل ندخل حظر
                    should_cd, cd_reason = should_enter_cooldown(cooldown, row['ts'])
                    if should_cd:
                        # استخلاص المدة من الـ reason (DURATION=Xh)
                        dur = 24  # افتراضي
                        if 'DURATION=' in cd_reason:
                            try:
                                dur_str = cd_reason.split('DURATION=')[1].split('h')[0]
                                dur = int(dur_str)
                            except: pass
                        activate_cooldown(cooldown, row['ts'], duration_hours=dur)
            continue
        if pending:
            entry_price = pending['pos_a']['entry']
            
            # ═══ UPGRADE 1: Entry Confirmation (اختياري — معطل حالياً) ═══
            # مصدر: ICT 2022 Mentorship Ep13 & 26
            # لما فعّال: لمس CE → وضع تأكيد → فحص 6 شموع → دخول أو رفض
            # لما معطل: لمس CE → دخول فوري (الأساسي)
            if ENTRY_CONFIRMATION_ENABLED:
                confirm_state = pending.get('_confirmation_state')
                
                if confirm_state and confirm_state.awaiting:
                    candle_5m = {'o': row['o'], 'h': row['h'], 'l': row['l'], 'c': row['c'], 'v': row.get('v', 0)}
                    confirmed, rejected_entry, reason = check_entry_confirmation(
                        confirm_state, candle_5m, atr=pending.get('atr', 1.0))
                    if confirmed:
                        for leg in ('pos_a', 'pos_b', 'pos_c'): pending[leg]['entry_filled'] = True
                        pending['signal_time'] = pending['entry_time']
                        pending['entry_time'] = row['dt']
                        pending['entry_type'] = "CE_CONFIRMED_ENTRY"
                        active = pending; pending = None; c1 = c4 = 0; continue
                    elif rejected_entry:
                        pending['cancel_reason'] = f'ENTRY_REJECTED: {reason}'
                        cancelled.append(pending); pending = None; continue
                    else:
                        continue
                
                entry_touched = row['l'] <= entry_price <= row['h']
                if entry_touched and not confirm_state:
                    is_long_pending = not pending['is_short']
                    pending['_confirmation_state'] = start_confirmation(
                        ce_level=entry_price, is_long=is_long_pending, max_candles=6)
                    continue
                elif not entry_touched:
                    pending['limit_candles_left'] -= 1
                    if pending['limit_candles_left'] <= 0: cancelled.append(pending); pending = None
                    continue
            else:
                # ═══ المنطق الأساسي: لمس CE → دخول فوري ═══
                if row['l'] <= entry_price <= row['h']:
                    for leg in ('pos_a', 'pos_b', 'pos_c'): pending[leg]['entry_filled'] = True
                    pending['signal_time'] = pending['entry_time']
                    pending['entry_time'] = row['dt']
                    active = pending; pending = None; c1 = c4 = 0; continue
                else:
                    pending['limit_candles_left'] -= 1
                    if pending['limit_candles_left'] <= 0: cancelled.append(pending); pending = None
                    continue
        if idx % 1 != 0: continue
        sess = classify_session(row['ts'])
        if sess['session'] not in EXEC: continue
        # ═══ Structural Cooldown — معطل مؤقتاً ═══
        # ⚠️ التفعيل بـ 2 خسائر = يمنع صفقات رابحة (Sep -4.04%)
        # ⚠️ التفعيل بـ 3 خسائر = ما يمنع كفاية (Oct no change)
        # الحل الأفضل: Dynamic Cash Allocation (تقليل الحجم بدل المنع)
        # in_cd, cd_reason = is_in_cooldown(cooldown, row['ts'])
        # if in_cd: continue
        # فلتر السبت — لا سيولة مؤسساتية IPDA (BTC فقط! ETH يختلف)
        if is_saturday_ny(row['ts']) and profile.block_saturday: continue
        scans += 1
        full = slice_data(rows, idx, 8000)
        d5 = slice_data(rows, idx, 250)
        d15 = aggregate(full, 15)
        d4h = aggregate(full, 240)
        d1d = aggregate(full, 1440)
        if not d1d or len(d1d['closes']) < 10 or not d15: continue
        bias = read_bias(d1d, d4h)
        if bias['direction'] not in ('BULLISH', 'BEARISH') or bias['confidence'] < 50: continue
        narr = read_narrative(d15, bias['direction'])
        sweep_obj = narr.get('sweep') or {}
        if narr['state'] != 'SWEEP_FOUND' or sweep_obj.get('quality', 0) < 25: continue
        trig = read_trigger(d5, narr, bias['direction'])
        if not trig['ready']: continue
        plan = build_plan(d5, d1d, trig, narr, bias)
        if not plan: continue
        is_long = bias['direction'] == 'BULLISH'
        fk = (round(trig['fvg']['top'], 2), round(trig['fvg']['bottom'], 2))
        if (fk, is_long) in entered: continue
        mid = midnight_open(rows, idx)
        disp_score = float(trig['displacement']['conviction'])
        dealing_15m = narr.get('dealing_range')
        ok, reason = entry_accumulation_filters(is_long, plan['entry'], bias, mid,
            displacement_score=disp_score, dealing_15m=dealing_15m, last_ob_held=True, current_price=plan['entry'])
        if not ok: rejected += 1; continue
        sl_atr = plan.get('sl_atr', 0)
        if sl_atr > 0 and sl_atr < 2.8: rejected += 1; continue
        confluence = 0
        if bias.get('direction') in ('BULLISH', 'BEARISH') and bias.get('confidence', 0) >= 70: confluence += 1
        if narr.get('sweep') and narr['sweep'].get('quality', 0) >= 50: confluence += 1
        if trig.get('displacement') and trig['displacement'].get('conviction', 0) >= 80: confluence += 1
        if trig.get('fvg') and trig['fvg'].get('ce') is not None: confluence += 1
        if trig.get('displacement', {}).get('index') is not None: confluence += 1
        if 'CONT_UNLOCKED' in reason: confluence += 1
        if 'CONT_UNLOCKED' in reason and confluence < 4: rejected += 1; continue
        tp1_rr = abs(plan['tp1']['price'] - plan['entry']) / plan['risk'] if plan['risk'] > 0 else 0
        if tp1_rr < 1.5: rejected += 1; continue
        entered.add((fk, is_long))
        sw = detect_ict_three_candle_swings(d1d)
        targs = sw['swing_highs'] if is_long else sw['swing_lows']
        tp3 = None
        for s in targs:
            if (is_long and s['price'] > plan['entry'] + plan['risk'] * 5) or (not is_long and s['price'] < plan['entry'] - plan['risk'] * 5):
                tp3 = s['price']; break
        ss, se = (min(narr['sweep']['wick_extreme'], plan['sl']), max(trig['fvg']['top'], plan['entry'])) if is_long else (max(narr['sweep']['wick_extreme'], plan['sl']), min(trig['fvg']['bottom'], plan['entry']))
        # ═══ Dynamic Cash Allocation — تعديل حجم المخاطرة ═══
        risk_mult = get_risk_multiplier(cash_alloc, balance)
        adj_risk = RISK * risk_mult
        pending = {
            'symbol': symbol, 'entry_time': row['dt'], 'session': sess['session'],
            'bias': bias['direction'], 'bias_conf': bias['confidence'],
            'entry': plan['entry'], 'sl': plan['sl'], 'risk': plan['risk'],
            'atr': plan['atr'], 'sl_atr': plan.get('sl_atr', 0),
            'tp1': plan['tp1'], 'tp2': plan['tp2'], 'tp3': tp3,
            'is_short': not is_long,
            'risk_pct_a': adj_risk * 100 * 0.6, 'risk_pct_b': adj_risk * 100 * 0.3, 'risk_pct_c': adj_risk * 100 * 0.1,
            'pos_a': {'active': True, 'entry': plan['entry'], 'sl': plan['sl'], 'tp1': plan['tp1']['price'], 'tp1_hit': False, 'pnl': 0},
            'pos_b': {'active': True, 'entry': plan['entry'], 'sl': plan['sl'], 'tp2_price': plan['tp2'].get('price') if isinstance(plan['tp2'], dict) else None, 'be_set': False, 'pnl': 0},
            'pos_c': {'active': True, 'entry': plan['entry'], 'sl': plan['sl'], 'tp3_price': tp3, 'be_set': False, 'pnl': 0},
            'setup_start': ss, 'setup_end': se, 'mfe_r': 0, 'mae_r': 0, 'candle_count': 0,
            'is_limit_order': True, 'limit_candles_left': 72, 'events': [],
        }
        c1 = c4 = 0

    wins = len([t for t in trades if t.get('pnl_dollar', 0) > 0.01])
    losses = len([t for t in trades if t.get('pnl_dollar', 0) < -0.01])
    mfe_list = [t.get('mfe_r', 0) for t in trades]
    avg_mfe = sum(mfe_list) / len(mfe_list) if mfe_list else 0
    return {
        'balance': round(balance, 2), 'pct': round((balance/100-1)*100, 2),
        'trades': len(trades), 'wins': wins, 'losses': losses,
        'cancelled': len(cancelled), 'avg_mfe': round(avg_mfe, 2),
        'trade_details': trades
    }

# Determine which symbol and data
# For BTC: need lookback months before target month
month_year = MONTH[:7]  # e.g. '2023-12'
year = int(month_year[:4])
prev_month_num = int(month_year[5:7]) - 1
if prev_month_num == 0:
    prev_month_str = f"{year-1}-12"
else:
    prev_month_str = f"{year}-{prev_month_num:02d}"
load_months = [prev_month_str, month_year]

# Also load 2 months before for extra lookback
prev2_num = prev_month_num - 1
if prev2_num <= 0:
    prev2_str = f"{year-1}-{12+prev2_num:02d}" if prev2_num < 0 else f"{year-1}-12"
else:
    prev2_str = f"{year}-{prev2_num:02d}"
load_months_ext = [prev2_str] + load_months

symbol = SYMBOL
path = BTC_PATH if symbol == "BTC" else ETH_PATH

t0 = time.time()
print(f"[{VERSION}] Loading {symbol} for {load_months_ext}...")
data = load_data(path, load_months_ext)
print(f"  {len(data)} candles loaded in {time.time()-t0:.1f}s")

print(f"[{VERSION}] Running {month_year} {symbol}...")
t1 = time.time()
result = run(symbol, data, month_year)
elapsed = time.time() - t1

if result:
    print(f"\n{'='*70}")
    print(f"[{VERSION}] {month_year} {symbol}: ${result['balance']} ({result['pct']:+.2f}%) | {result['trades']} trades ({result['wins']}W/{result['losses']}L) | Avg MFE: {result['avg_mfe']}R | {result['cancelled']} cancelled | {elapsed:.0f}s")
    print(f"{'='*70}")
    for i, t in enumerate(result['trade_details']):
        events_str = ' | '.join(str(e) for e in t.get('events', [])[-5:]) if t.get('events') else 'none'
        print(f"  Trade {i+1}: entry={t['entry']:.1f} sl={t.get('sl',0):.1f} mfe={t.get('mfe_r',0):.2f}R pnl={t.get('pnl_pct',0):+.3f}% | {events_str}")
else:
    print(f"No results for {month_year}")
